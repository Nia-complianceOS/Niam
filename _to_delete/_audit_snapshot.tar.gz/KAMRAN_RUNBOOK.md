# Niam — Kamran's Runbook

Everything you actually run, by terminal, in order. Written for **Windows
PowerShell**, repository at `D:\niam\Niam`, venv at `backend\venv`.

**Rewritten 2026-09-08** after the multi-tenancy change, **updated
2026-09-25** after identity moved to Postgres. Three things about this
project are now different in ways that invalidate muscle memory:

1. **Every account has its own graph.** Nothing is global except the DPDP
   Act itself. Every CLI needs `--owner`, and an owner that matches no
   account is refused rather than writing a subgraph nobody can see.
2. **Each user connects their own GitHub.** The shared `GITHUB_TOKEN` no
   longer drives the app — it survives only as an explicit fallback for
   headless CLI runs. Scans and pull requests use the signed-in user's
   credentials.
3. **There are two databases now.** Accounts, GitHub connections, OAuth
   states, scan history and the audit log live in **Postgres, via
   Supabase**. Neo4j holds the compliance graph and nothing about people:
   `:User` nodes are no longer written, and `--owner` resolves against the
   `users` table. A deployment that names only Neo4j boots, answers
   `/health`, and fails on the first login.

If you are picking this up after time away, do **Part 1** once, then live
in **Part 2** and **Part 3**.

---

> ### Read this first — the Windows traps that have already cost us time
>
> 1. **`curl` in PowerShell is not curl.** It is an alias for
>    `Invoke-WebRequest` and rejects `-s`, `-i`, `-H`. **Type `curl.exe`.**
>    Every command below already does.
> 2. **`VAR=value command` does nothing in PowerShell.** Use
>    `$env:VAR = "value"`, which persists for that whole window. This is
>    why the terminal discipline below matters.
> 3. **Angle brackets break PowerShell.** `<` is a redirection operator, so
>    `run_scan_and_write <you>/repo` dies with *"The '<' operator is
>    reserved for future use."* Substitute placeholders without brackets.
>    Pasting a placeholder literally gives a 404 on a repo that does not
>    exist, which reads exactly like a permissions problem. It has happened
>    twice.
> 4. **Resetting `$env:Path` silently deactivates your venv.** The prompt
>    still says `(venv)` while `python` is the system one. Symptom:
>    `ModuleNotFoundError` for packages you know are installed. Check with
>    `python -c "import sys; print(sys.executable)"`. Do not hand-patch
>    PATH — open a fresh window and activate there.
> 5. **GitHub returns 404, not 403,** for a private repo a token cannot
>    see. A permissions problem looks exactly like a missing repository.
> 6. **Never set `$env:NEO4J_*` in a window that talks to Aura.** One
>    leaked variable and a destructive test runs against your demo graph.
>    Retitle any window you point at the local database — that title is the
>    only visible difference between the two.
> 7. **New:** a scan started from the UI runs as the signed-in user, but a
>    scan started from the CLI runs as whoever `--owner` names. Those can
>    be different people. Check the banner the CLI prints.

> ### Standing rule — Claude does not touch `.env`
> Every `.env` edit here is **yours**, in your own editor. Claude will never
> open, read, print or modify `backend\.env`. When something fails, paste
> the **error message** into chat — never the file.

---

# Step 0 — Pre-flight, every time

```powershell
cd D:\niam\Niam
git status                 # clean? if not, commit or stash before anything
docker ps                  # is the smoke database up?
```

If a previous session left a lock behind:

```powershell
Remove-Item .git\index.lock -ErrorAction SilentlyContinue
```

---

# Terminal layout — four windows

| # | Title | Purpose | Talks to |
|---|---|---|---|
| **T1** | `API` | Backend on :8000 | **Aura** |
| **T2** | `UI` | Frontend on :5173 | T1 |
| **T3** | `CLI` | intelligence CLIs | **Aura** |
| **T4** | `CHECKS` | curl, git, scripts | **Aura** |

**First command in every window:**

```powershell
$Host.UI.RawUI.WindowTitle = "API"          # change the string per window
```

## Why this used to be six, and why it is four now

The old layout ran a parallel stack — a second API on :8001 and a second UI
on :5174 — against a local Neo4j container, so that test scans could never
touch the demo graph. That was the right design when there was **one**
graph and everybody shared it.

Multi-tenancy replaced most of that job. A test account is now its own
subgraph, and `wipe_graph.py --owner` resets it without touching anything
else. Two accounts in one browser is also a *better* tenancy test than two
browsers against two databases: the thing you are testing is whether the
filters hold, and running each user against their own database proves
nothing about that.

The parallel UI was actively worse than useless once GitHub became
per-user: the local OAuth App's callback points at :8000, so connecting
GitHub on :5174 cannot complete a round trip at all.

**Start the local database only for the three jobs tenancy does not cover**
(Part 5A). Do not keep it running out of habit.

**Activating the venv** (needed in T1, T3 and T4):

```powershell
cd D:\niam\Niam
.\backend\venv\Scripts\Activate.ps1
```

If you get *"running scripts is disabled on this system"*:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\backend\venv\Scripts\Activate.ps1
```

Confirm the interpreter — this is the single most common cause of "it
worked yesterday":

```powershell
python -c "import sys; print(sys.executable)"
# expect: D:\niam\Niam\backend\venv\Scripts\python.exe
```

**T1, T2, T3 and T4 talk to Aura, so none of them may have
`$env:NEO4J_URI` set.** Check any window you are unsure about:

```powershell
if ($env:NEO4J_URI) { Write-Host "points at a local db - not Aura" -ForegroundColor Yellow }
else { Write-Host "clean - Aura" -ForegroundColor Green }
```

**Pointing a window at the local database** (only for Part 5A). This is
window-scoped, written nowhere, and overrides `.env` because real
environment variables win in both `python-dotenv` and `pydantic-settings`:

```powershell
$Host.UI.RawUI.WindowTitle = "LOCAL-DB"
$env:NEO4J_URI      = "bolt://localhost:7687"
$env:NEO4J_USERNAME = "neo4j"
$env:NEO4J_USER     = "neo4j"
$env:NEO4J_PASSWORD = "testpassword"
Write-Host "LOCAL DATABASE - not Aura" -ForegroundColor Yellow
```

Retitle the window. That title is the only thing standing between a
destructive test and your demo data.

---

# Part 1 — One-time setup

Do this once per install: **1.0** for the accounts database, then the
GitHub OAuth App, the new `.env` values, and a graph rebuild.

## 1.0 — Supabase: the accounts database

Everything about people moved out of Neo4j. Without these two values the
API starts, `/api/v1/health` answers, and the first login fails — which is
a confusing place to discover a missing key.

**Create the project** at <https://supabase.com> (free tier is enough).
Then, in the project:

1. **SQL Editor** → run `backend\migrations\001_initial_schema.sql`, then
   `backend\migrations\002_lock_down_postgres.sql`. Run them in that
   order. 002 is safe to re-run and safe on a database that never had
   001's policies.
2. **Project Settings → API** → copy the **Project URL** and the
   **service-role / secret key**. Put them in `backend\.env` yourself:

```ini
SUPABASE_URL=https://<project-ref>.supabase.co
SUPABASE_SECRET_KEY=...
```

Why the secret key and not the anon key: the backend is the only thing
that talks to Postgres, and it enforces the per-account boundary itself,
in every query, guarded by `backend\tests\test_tenancy_scoping.py`. 002
drops the row-level-security policies 001 created, because this app issues
its own JWTs and never calls `supabase.auth` — so `auth.uid()` was always
NULL and those policies denied everyone by accident while looking like
protection. The `users` table holds password hashes; a policy that looks
protective is one "let the frontend read its own row" away from exposing
them.

**Nothing Supabase-shaped belongs in the frontend.** The browser bundle
used to ship a Supabase client with the anon key and a type declaring
`users.hashed_password`. It is deleted. `frontend\.env` holds
`VITE_API_BASE_URL` and nothing else.

**Check it:**

```powershell
curl.exe -s http://localhost:8000/api/v1/health
# expect neo4j_connected: true AND supabase_connected: true
```

> `smoke\preflight.ps1` predates this and still checks only
> `GITHUB_TOKEN`, `GEMINI_API_KEY`, `NEO4J_URI` and `NEO4J_PASSWORD`. The
> health endpoint above is the authoritative check until it is updated.

## 1.1 — Register the GitHub OAuth App

<https://github.com/settings/developers> → **OAuth Apps** → **New OAuth
App**. Free, unlimited users, about two minutes.

GitHub's form now says **Redirect URIs** (plural) where it used to say
*Authorization callback URL*. Same thing, new name — and it takes **up to
ten**, so **one app covers both local development and production**. You do
not need two.

| Field | Value |
|---|---|
| Application name | `Niam` |
| Homepage URL | `http://localhost:5173` (change to the Vercel URL after deploying) |
| Application description | One line — users see this on the consent screen. e.g. *"Finds personal data in your code and checks it against India's DPDP Act."* |
| Redirect URI 1 | `http://localhost:8000/api/v1/github/oauth/callback` |
| Redirect URI 2 | `https://niam-api.onrender.com/api/v1/github/oauth/callback` |
| Allow wildcard matching | **off** |
| Enable Device Flow | **off** |
| Expire user access tokens | **off** — see below |

Add the second redirect URI now even though Render does not exist yet; it
costs nothing and saves editing the app mid-deploy. Adjust the hostname
once you know it.

**The redirect URI points at the BACKEND, not the frontend.** GitHub sends
the browser to the backend with a code; the backend exchanges it and then
redirects onward to `FRONTEND_URL`. Pointing this at :5173 produces a
confusing failure where GitHub succeeds and nothing happens.

**Leave the three toggles off:**

- *Allow wildcard matching* — it would let tokens go to any subdomain or
  path under a registered URI. There is no reason to widen the target of a
  credential handoff.
- *Enable Device Flow* — for devices with no browser. Not this.
- *Expire user access tokens* — this issues 8-hour tokens plus a
  `refresh_token`, and **nothing in Niam implements the refresh exchange
  yet**. Turn it on and every connection silently stops working after
  eight hours, surfacing as "connect your GitHub account" on an account
  that already did. Worth implementing later; wrong to enable now.

Then **Generate a new client secret**. GitHub shows it once.

## 1.2 — New values in `backend\.env`

Your editor, not the terminal. Add:

```ini
# --- per-user GitHub connection ---
GITHUB_CLIENT_ID=Ov23li...
GITHUB_CLIENT_SECRET=...
FRONTEND_URL=http://localhost:5173

# Which of the app's registered redirect URIs THIS machine uses.
# Required once the app has more than one, or GitHub picks for you.
GITHUB_OAUTH_REDIRECT_URI=http://localhost:8000/api/v1/github/oauth/callback

# --- encrypts each user's stored GitHub token at rest ---
TOKEN_ENCRYPTION_KEY=

# --- the accounts database (1.0) ---
SUPABASE_URL=https://<project-ref>.supabase.co
SUPABASE_SECRET_KEY=...
```

Generate the encryption key in **T4** and paste the output in:

```powershell
python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"
```

Notes worth knowing before something confuses you later:

- Without `TOKEN_ENCRYPTION_KEY`, development derives a key from
  `JWT_SECRET` and logs a loud warning. **Outside development the app
  refuses to store a token at all** rather than keeping one in plaintext.
- Rotating that key invalidates every stored connection. Users are asked to
  reconnect — which is the correct failure, not a 500.
- `GITHUB_TOKEN` stays in `.env`. It is now **only** a fallback for headless
  CLI runs. Nothing on the API path will use it, because a user seeing
  repositories belonging to whoever owns that PAT is a data leak.
- Without `GITHUB_CLIENT_ID`/`SECRET` the OAuth routes return 503 and the
  paste-a-token fallback is the only way to connect. That is a usable
  offline demo path, not a broken state.
- `GITHUB_OAUTH_REDIRECT_URI` must match a registered URI **exactly** —
  scheme, host, port, path, no trailing slash. A mismatch fails at the
  token exchange with a generic error that says nothing about URIs, which
  is a miserable thing to debug. Copy-paste it from the GitHub form.

## 1.3 — Install the dependencies

**T4**, venv active:

```powershell
pip install -r backend\requirements.txt
pip install -e .\intelligence
python -c "from cryptography.fernet import Fernet; print('cryptography ok')"
python -c "import slowapi, supabase; print('slowapi + supabase ok')"
```

`slowapi` is imported by `app\main.py` at module load, so a checkout
without it does not start the API at all — `ModuleNotFoundError` before the
first request, not on first use of rate limiting.

`intelligence\pyproject.toml` declares `supabase` and `python-dotenv`
itself, so `pip install -e .\intelligence` is now sufficient for the CLIs
on its own. They no longer depend on anyone having installed the backend
first.

## 1.4 — Wipe the graph

Everything written before the tenancy change is unowned: no `owner_id`, no
scoped `uid`. Those nodes match no account's queries, so they are invisible
in the app while still occupying Aura's budget and confusing anyone who
opens the Neo4j browser.

**T4**, venv active, no `NEO4J_*` set:

```powershell
cd D:\niam\Niam
python smoke\wipe_graph.py            # report only - CHECK THE URI IT PRINTS
python smoke\wipe_graph.py --yes
```

The script prints the target URI and warns when it is not local. Read that
line before you type `--yes`.

**It no longer keeps account nodes, because there are none.** Accounts
live in Postgres, so `wipe_graph.py`'s account-label list is empty and
`--users` deletes nothing. Signing up again is not part of a wipe: your
account survives any graph wipe, and only its subgraph goes.

**Once per database, clear what the move left behind:**

```powershell
cd D:\niam\Niam\intelligence
python -m graph.cleanup_migrated              # counts only
python -m graph.cleanup_migrated --yes
```

That deletes the orphaned `:User`, `:GithubConnection` and
`:GithubOAuthState` nodes from the Neo4j era. Nothing reads them, and
leaving them there makes the graph browser lie about where identity
lives.

Do the same against the local database later, if and when you start it
(Part 5A). There is no rush: it is empty until you use it.

> **From here on you rarely need this form again.** Resetting one account
> is `python smoke\wipe_graph.py --owner you@example.com --yes`, which
> leaves every other account and the shared Act alone and is safe on any
> database. The instance-wide wipe also deletes the Act, so the next run
> re-extracts it — two minutes and a Gemini call per section.

## 1.5 — Rebuild the shared reference data

The Act is loaded once per database and shared by every account. Per
database:

**T3**, venv active (any directory):

```powershell
python -m graph.apply_schema --owner you@example.com
python -m legal.load_dpdp_clauses --yes
```

`load_dpdp_clauses` takes **no** `--owner` on purpose — the Act is the same
law for everyone and costs a Gemini call per section. `apply_schema` takes
one only so no invocation runs unnamed; constraints are instance-wide.

Expect roughly two minutes and 44 sections. A few sections failing to parse
is normal and reported.

## 1.6 — Refresh the frontend, then sign up and connect

The design-system work changed the frontend's dependencies, and the
Supabase client was removed from them. After pulling:

```powershell
cd D:\niam\Niam\frontend
npm install
```

`frontend\DESIGN.md` is where the design system's rules live — read it
before adding a component.


Start the stack (Part 2), open the UI, and **sign up**. There is no seed
account. The account you create is a row in the Supabase `users` table,
and it is the tenant everything else hangs off.

Then Repositories → **Connect GitHub** → authorise → you land back on
Repositories with your GitHub login shown. Pick `niam-smoke-repo` and scan.

That is now the intended path. The CLIs still work and are useful for
debugging, but the product is the UI.

---

# Part 2 — Starting the stacks

## The demo stack (Aura)

**T1**

```powershell
$Host.UI.RawUI.WindowTitle = "DEMO-API"
cd D:\niam\Niam\backend
.\venv\Scripts\Activate.ps1
uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
```

**T2**

```powershell
$Host.UI.RawUI.WindowTitle = "DEMO-UI"
cd D:\niam\Niam\frontend
npm run dev
```

<http://localhost:5173>.

> Pages stuck on "Loading compliance data…" mean Aura auto-paused (Free
> tier does this after ~3 days idle). Resume it in the console **and
> restart T1** — the driver is cached for the life of the process and will
> not reconnect on its own.

## The local database — only when you need it

See Part 5A for what it is still for. When you do need it:

```powershell
docker compose up -d neo4j
```

Wait 30–45 seconds for Bolt. <http://localhost:7474>, `neo4j` /
`testpassword`. Then point ONE window at it using the block in the terminal
section above, and retitle that window `LOCAL-DB`.

An API against it, if the test needs one:

```powershell
cd D:\niam\Niam\backend
.\venv\Scripts\Activate.ps1
# ...paste the local-database block, retitle the window...
uvicorn app.main:app --port 8001 --host 127.0.0.1
```

> There is no second UI any more. If a test needs a browser, point the
> existing one at it with `$env:VITE_API_BASE_URL` — but note that GitHub
> OAuth cannot complete against :8001, because the local OAuth App's
> callback is registered for :8000. Use the paste-a-token fallback there;
> it involves no callback at all.

## Shutting down

`Ctrl+C` in T1 and T2. If you started the local database:

```powershell
docker compose stop neo4j       # keeps the data
docker compose down -v          # deletes it entirely
```

---

# Part 3 — The user journey

This is the flow to walk through before any demo, and the one to hand a
judge. Every step is something a real user does.

1. **Sign up.** A `:User` node with a hashed password. The JWT it returns is
   what scopes every subsequent query.
2. **Land on an empty dashboard.** No score — an explanation instead. This
   is correct: nothing has been scanned, so there is nothing to score, and
   the one thing this app must never do is invent a number.
3. **Repositories → Connect GitHub.** GitHub's consent screen, then back.
   Your login and avatar appear. (Or: "paste a token instead", collapsed
   below the button.)
4. **Pick a repository and scan.** Progress streams live. `niam-smoke-repo`
   takes about 90 seconds.
5. **Dashboard fills in.** Score, vendors, data types — all from the graph,
   all yours.
6. **Compliance Gaps.** Findings worst-severity-first. Pick one, read the
   plain-language panel, draft a fix.
7. **Open a pull request.** With `GITHUB_DRY_RUN=true` (the default) it logs
   what it would push and creates nothing. That is the safe demo.
8. **Log out. Sign up as somebody else.** They see step 2 again — an empty
   dashboard, no vendors, no findings, no GitHub connection. **This is the
   check that matters most.** See T-1 below.
9. **Log back in as yourself.** Everything is where you left it.

---

# Part 4 — CLI reference

Run these in **T3** with the venv active. They work from **any**
directory now — the repository root, `intelligence\`, anywhere. Add the
local-database block first only if you are deliberately targeting the
local container.

> Until 2026-09-08 they only worked from `intelligence\`: every module
> found `backend\.env` with `find_dotenv("../backend/.env", usecwd=True)`,
> which resolves relative to wherever you happen to be standing. Run one
> from the repository root and it found nothing, loaded nothing, and
> failed several frames later with *"Missing Neo4j credentials"* —
> pointing at a `.env` file that was perfectly fine. The path is computed
> from the module's own location now.

```powershell
cd D:\niam\Niam\intelligence
..\backend\venv\Scripts\Activate.ps1
```

| Command | Owner? | What it does |
|---|---|---|
| `python -m graph.apply_schema --owner EMAIL` | recorded only | Constraints + indexes. Instance-wide; safe to re-run |
| `python -m legal.load_dpdp_clauses --yes` | **no** | Fetches and extracts the Act. Shared by everyone |
| `python -m graph.run_scan_and_write OWNER/REPO --owner EMAIL --system NAME --yes` | yes | Scan a repo into that account's graph |
| `python -m legal.load_policies --owner EMAIL --dir ..\smoke\fixtures --yes` | yes | Read legal documents into that account |
| `python -m legal.load_policies --owner EMAIL --repo OWNER/REPO --yes` | yes | Same, from a repository |
| `python -m reconciliation.run_reconciliation --owner EMAIL --system NAME --yes` | yes | Compare all three sides, write gaps |
| `python -m retrieval.query_cli summary --owner EMAIL` | yes | What is actually in that account's graph |

**`--owner` takes an email or a user id and resolves it against the
`users` table in Postgres** — by id, or case-insensitively by email. An
owner matching no account is refused with the list of accounts that do
exist. That refusal is deliberate: before it, `--owner alice@example.com`
would have written a complete, correct and permanently invisible subgraph,
because the app scopes by the uuid minted at signup and Alice's dashboard
would have stayed empty forever.

**So every CLI now needs `SUPABASE_URL` and `SUPABASE_SECRET_KEY` in
`backend\.env`**, next to the `NEO4J_*` values. Without them the CLI stops
before doing anything and names the two keys. Until 2026-09-17 the lookup
ran `MATCH (u:User {id: $value})` against Neo4j, which after the move
could only ever return nothing — so every CLI refused to run and blamed
you for not having signed up. The lookup opens no Neo4j connection at
all.

**Full rebuild for one account, from empty:**

```powershell
python -m graph.apply_schema --owner you@example.com
python -m legal.load_dpdp_clauses --yes
python -m graph.run_scan_and_write niacomplianceos/niam-smoke-repo --owner you@example.com --system niam-smoke --yes
python -m legal.load_policies --owner you@example.com --dir ..\smoke\fixtures --yes
python -m reconciliation.run_reconciliation --owner you@example.com --system niam-smoke --yes
python -m retrieval.query_cli summary --owner you@example.com
```

> **Step 4 fails silently if skipped.** With no `:PolicyDocument` the
> reconciler skips disclosure checks entirely rather than reporting every
> data type as undisclosed. The symptom is *no* "shared without disclosure"
> findings — not an error.

---

# Part 5 — Checks

## 5A — What the local database is still for

Tenancy made most of the old rig redundant. Three jobs it does **not**
cover, because each is instance-wide and reaches every account at once:

1. **Anything that changes the schema.** `apply_schema` writes constraints
   and indexes across the whole instance. A new constraint that conflicts
   with existing data fails the whole statement.
2. **Anything that touches the shared Act.** Re-running
   `load_dpdp_clauses`, or changing how clauses are tagged, changes what
   every account is measured against.
3. **Testing the isolation itself.** This is the important one. You cannot
   validate an owner filter using only that filter. If `RESOLVE_STALE_GAPS`
   or a delete has a bug that ignores `owner_id`, running it against Aura
   destroys the demo data — and the bug you were testing for is exactly the
   reason it did.

Everything else — features, UI, a normal scan, tenancy behaviour as seen by
a user — is better tested with two accounts on the real stack, and reset
with `wipe_graph.py --owner`.

**Resetting a test account, safe on any database:**

```powershell
python smoke\wipe_graph.py --owner bob@test.local            # what would go
python smoke\wipe_graph.py --owner bob@test.local --yes      # go
```

That account is then exactly as it was the second it signed up.

---

## T-1 — Tenancy isolation ⚠️ the one that matters

Run this after any change to a query. A forgotten `owner_id` filter does not
raise; it shows one user another user's vendor names, source file paths and
private-repo commit SHAs.

**Setup, on the normal stack (:5173) — two accounts, one browser:**

1. Sign up as `alice@test.local`. Connect GitHub. Scan `niam-smoke-repo`.
   Wait for gaps to appear.
2. Log out.
3. Sign up as `bob@test.local`. Do not connect anything.

**Bob must see, with no exceptions:**

| Page | Expected |
|---|---|
| Dashboard | Empty state, score `—` with an explanation. Not 0, not 100 |
| Compliance Graph | "No map to show yet" — **and no orphan clause nodes** |
| Compliance Gaps | Empty. Not one of Alice's 40 |
| Vendors | Empty. Not Stripe/Mixpanel/SendGrid |
| Repositories | "Connect GitHub" — not Alice's repo list |
| Policies, PRs, Audit | Empty |

4. Log out. Log back in as Alice. **Everything is exactly as she left it.**

**Then the API directly, in T4** — the UI could be hiding a leak behind a
filter:

```powershell
$alice = (curl.exe -s -X POST -H "Content-Type: application/json" -d '{\"email\":\"alice@test.local\",\"password\":\"...\"}' http://localhost:8000/api/v1/auth/login | ConvertFrom-Json).access_token
$bob   = (curl.exe -s -X POST -H "Content-Type: application/json" -d '{\"email\":\"bob@test.local\",\"password\":\"...\"}' http://localhost:8000/api/v1/auth/login | ConvertFrom-Json).access_token

# Alice has findings
(curl.exe -s -H "Authorization: Bearer $alice" http://localhost:8000/api/v1/gaps | ConvertFrom-Json).gaps.Count

# Bob must be 0
(curl.exe -s -H "Authorization: Bearer $bob"   http://localhost:8000/api/v1/gaps | ConvertFrom-Json).gaps.Count

# Bob's graph must be empty
(curl.exe -s -H "Authorization: Bearer $bob"   http://localhost:8000/api/v1/graph | ConvertFrom-Json).nodes.Count

# Bob cannot fetch one of Alice's gaps by id -> 404, never 200
curl.exe -s -o NUL -w "%{http_code}`n" -H "Authorization: Bearer $bob" http://localhost:8000/api/v1/gaps/PASTE_AN_ALICE_GAP_ID
```

Any non-zero count for Bob, or a 200 on that last line, is a data leak. Stop
and fix it before anything else.

## T-2 — MERGE_GAP edge attachment ⚠️ unverified

`MERGE_GAP` was restructured during the tenancy work to fix a pre-existing
bug: it used `UNWIND (CASE WHEN $remediation_doc_id IS NOT NULL ...)`, and
unwinding an empty list eliminates the row — so for every gap with no
remediation document, i.e. **every Act-coverage gap**, the `INVOLVES`,
`AFFECTS` and `VIOLATES` clauses after it never ran. Those gaps reached the
drafter with no data type and no clauses attached.

The fix could not be tested — no Neo4j was reachable from the session that
made it. **Verify it on the rig before trusting any coverage gap.** In the
Neo4j browser at <http://localhost:7474>:

```cypher
// Every gap should have at least one INVOLVES edge. Expect zero rows.
MATCH (g:Gap) WHERE NOT (g)-[:INVOLVES]->(:DataType)
RETURN g.id, g.kind, g.title LIMIT 25
```

```cypher
// Coverage gaps should cite clauses. Expect zero rows.
MATCH (g:Gap) WHERE g.kind IN ['ungoverned_egress','ungoverned_collection']
  AND NOT (g)-[:VIOLATES]->(:DPDPClause)
RETURN g.id, g.kind LIMIT 25
```

## T-3 — Fresh-account empty state

Sign up a throwaway account and confirm every page renders a purposeful
empty state — not a spinner, not a red error, not a zero-filled dashboard.
The score must be `—` with the backend's explanation, never a number.

## T-4 — GitHub connection

1. Repositories on a fresh account → Connect panel, no error.
2. Connect → GitHub consent → back with your login shown.
3. The repo picker lists **your** repositories, searchable, ten at a time.
4. Disconnect → back to the Connect panel.
5. Paste-a-token fallback works with a fine-grained PAT.
6. Interrupt an OAuth flow and reuse the old callback URL → refused as
   expired, not accepted.

## T-5 — Logout leaves nothing

With Alice signed in and data on screen, log out and sign in as Bob
**without refreshing the page**. Watch for any frame of Alice's data. The
authenticated tree is keyed on the user id so it unmounts entirely, but this
is worth watching once with your own eyes.

## T-6 — Tests

```powershell
cd D:\niam\Niam\intelligence
python -m pytest reconciliation\test_reconciler.py reasoning\test_verifier.py -q

cd D:\niam\Niam\backend
python -m pytest tests -q
```

The backend suite is `test_dashboard_service.py`, `test_empty_account.py`,
`test_supabase_services.py` and `test_tenancy_scoping.py`. All of it must
pass; the counts move as tests are added, so read the result, not a
remembered number.

`backend\tests\test_tenancy_scoping.py` is a static guard: it greps the
service layer for owned-label matches without an owner filter, with an
explicit allowlist for the three deliberate exceptions. If you add a query,
that test is what catches a missing filter.

```powershell
cd D:\niam\Niam\frontend
npx tsc -b --noEmit                                                                # silent
```

---

# Part 6 — Troubleshooting

| Symptom | Cause |
|---|---|
| Dashboard empty after a CLI scan | `--owner` did not name the account you are signed in as. Check with `python -m retrieval.query_cli summary --owner EMAIL` |
| `No account matches --owner ...` | Sign up in the app first. The CLI writes into an existing account; it does not create one. The list it prints comes from the `users` table in Postgres |
| `SUPABASE_URL and SUPABASE_SECRET_KEY are not set` from a CLI | 1.0 — they belong in `backend\.env` beside the `NEO4J_*` values. The CLIs resolve `--owner` against Postgres, not the graph |
| `ModuleNotFoundError: No module named 'supabase'` | `pip install -e .\intelligence` in this venv — the package declares it |
| API will not start: `ModuleNotFoundError: No module named 'slowapi'` | `pip install -r backend\requirements.txt`. It is imported at module load, so nothing works without it |
| Login fails in production while `/health` looks fine | `SUPABASE_URL`/`SUPABASE_SECRET_KEY` not set on Render. Health does not prove the accounts database is reachable — check `supabase_connected` in its body |
| `:User` nodes visible in the Neo4j browser | Leftovers from before identity moved. `python -m graph.cleanup_migrated --yes` (1.4) |
| `ModuleNotFoundError: No module named 'graph'` | `pip install -e .\intelligence` missing, or wrong venv. Check `python -c "import sys; print(sys.executable)"` |
| `Missing Neo4j credentials` with a `.env` that is definitely correct | Fixed 2026-09-08 — the loader searched relative to your working directory. If it recurs, check `python -c "from graph.env import load_env; print(load_env())"`; `None` means no file was found and the environment is being used as-is |
| Every page "Graph unreachable" | Aura paused, or wrong `NEO4J_*`. After resuming, **restart the API** |
| Repositories shows Connect when already connected | The token was stored under a different `TOKEN_ENCRYPTION_KEY`. Rotating it invalidates connections by design — reconnect |
| OAuth returns "that attempt had expired" | State is single-use with a 10-minute TTL. Start again from the button |
| OAuth returns "not set up on this instance" | `GITHUB_CLIENT_ID`/`SECRET` unset. Use the paste-a-token fallback |
| Callback lands on localhost in production | `FRONTEND_URL` still at its default on Render |
| Scan 404s a repo you can see | The connected GitHub account cannot see it. GitHub returns 404, not 403 |
| PR "opened" but not on GitHub | `GITHUB_DRY_RUN=true`, the default |
| "You already have a scan running" | Not an error. One at a time per user; see `SCAN_RATE_LIMIT_PER_HOUR` |
| No "shared without disclosure" findings | `load_policies` never ran for that account |
| `.git\index.lock` exists | `Remove-Item .git\index.lock` |

---

# Part 7 — Deployment

`ACTION_PLAN.md` Phase I. I.0, I.1, I.5 and I.6 are done. What is left is
yours, in order — and one item is new since the tenancy change.

0. **The accounts database, first.** Decide whether production shares your
   development Supabase project or gets its own. If it gets its own, run
   both migrations there (1.0) before the first deploy — the API will boot
   happily against an empty project and fail at login.
1. **I.2 — Render.** New → Blueprint → connect the repo. `render.yaml`
   names every variable. Fill the `sync: false` ones: **`SUPABASE_URL`,
   `SUPABASE_SECRET_KEY`**, the three `NEO4J_*`, `GEMINI_API_KEY`,
   `GITHUB_TOKEN`, `GITHUB_WEBHOOK_SECRET`, `PR_ALLOWED_REPOS`,
   **`GITHUB_CLIENT_ID`, `GITHUB_CLIENT_SECRET`, `TOKEN_ENCRYPTION_KEY`**
   (a fresh Fernet key, not your local one). Leave `CORS_ORIGINS` and
   `FRONTEND_URL` blank for now. Verify `/api/v1/health` returns
   **both** `neo4j_connected: true` and `supabase_connected: true`.
2. **I.3 — Vercel.** Import the repo, root directory `frontend`, set
   `VITE_API_BASE_URL` to `https://<service>.onrender.com/api/v1` for both
   Production and Preview. That is the only variable the frontend needs —
   no Supabase keys reach the browser. Deploy, copy the URL.
3. **I.4 — Back to Render.** Set `CORS_ORIGINS` **and `FRONTEND_URL`** to
   that Vercel URL. Both matter now: without `FRONTEND_URL`, every user who
   connects GitHub in production is redirected to their own localhost.
4. **New — the OAuth App and its redirect URI.** Confirm the app's second
   redirect URI is the real Render hostname
   (`https://<service>.onrender.com/api/v1/github/oauth/callback`), then
   set `GITHUB_OAUTH_REDIRECT_URI` on Render to that same string. One app
   serves both environments; the env var is what selects which URI each
   one uses. Also update the app's Homepage URL to the Vercel URL — users
   see it on the consent screen.
5. **I.7 — Aura.** Free tier pauses after ~3 days and is deleted after 30
   days idle. Confirm Running before any demo, restart Render after
   resuming, snapshot before judging.
6. **I.8 — Rotate `GITHUB_TOKEN`** after the first deploy.

**Before the link goes on a CV:** sign up on the deployed instance as a
fresh user and walk Part 3 end to end. Load policy documents for that
account, or the whole disclosure half of the graph is empty — the sample
documents live in `smoke/fixtures/`, which is gitignored, so on Render use
`load_policies --repo` against a real repository. That decision is still
open.

---

# Appendix — history

Since the 2026-09-08 rewrite: identity moved out of Neo4j into Postgres
via Supabase, the intelligence CLIs were repointed at the `users` table,
the Postgres boundary was made real rather than decorative (migration
002), `slowapi` was pinned, `render.yaml` learned about the second
database, and the Supabase client was deleted from the browser bundle.

Phases S, A, B, C, D, E, F, G and H are complete and their detail lives in
`ACTION_PLAN.md`, which records the reasoning as well as the steps. The
sections that used to be here — building the throwaway rig, creating the
junk repo, rotating the PAT, the rename, consolidating `.env` — described
one-time work that is done. `SESSION_HANDOFF.md` is the architectural
picture; `CODEBASE_AUDIT.md` is where the whole thing started.
