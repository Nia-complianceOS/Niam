# ============================================================
# Remove the Claude co-author trailer from the nine commits that
# carry it, so GitHub stops showing a second contributor.
#
#   cd D:\niam\Niam
#   Remove-Item .git\index.lock -ErrorAction SilentlyContinue
#   powershell -ExecutionPolicy Bypass -File .\smoke\remove_claude_coauthor.ps1
#
# This REWRITES HISTORY. It stops before pushing and prints exactly
# what to check. Read the checks before you force-push.
#
# What it touches: b3f20de..HEAD -- nine commits, all authored by you,
# contiguous, with none of Pragya's commits among them. Her work is all
# below b3f20de and its SHAs do not change.
# ============================================================

$ErrorActionPreference = 'Stop'
$BASE   = 'b3f20de'
$FILTER = 'smoke/strip_claude_trailer.sh'

function Step($t) { Write-Host ""; Write-Host "== $t" -ForegroundColor Cyan }

if (-not (Test-Path .git))     { throw "Not a git repo. cd to D:\niam\Niam first." }
if (Test-Path .git\index.lock) { throw "Stale .git\index.lock - run: Remove-Item .git\index.lock" }
if (-not (Test-Path $FILTER))  { throw "$FILTER missing." }
if ((git status --porcelain | Where-Object { $_ -notmatch '^\?\?' }).Count -gt 0) {
    git status --short
    throw "Working tree is dirty. filter-branch refuses to run. Commit or stash first."
}

$repoRoot = (git rev-parse --show-toplevel).Trim()   # forward slashes already
$filterAbs = "$repoRoot/$FILTER"

# --- a way back ---------------------------------------------------------
Step "Recording a backup ref"
$before = (git rev-parse HEAD).Trim()
git branch -f backup/pre-coauthor-strip $before
Write-Host "  backup/pre-coauthor-strip -> $before" -ForegroundColor Yellow
Write-Host "  To undo everything BEFORE pushing:" -ForegroundColor Yellow
Write-Host "      git reset --hard backup/pre-coauthor-strip" -ForegroundColor White

# --- the rewrite --------------------------------------------------------
Step "Rewriting $BASE..HEAD"
$env:FILTER_BRANCH_SQUELCH_WARNING = '1'
git filter-branch -f --msg-filter "sh '$filterAbs'" "$BASE..HEAD"

# --- checks -------------------------------------------------------------
Step "CHECK 1 - no trailer survives"
$left = git log --grep='Co-Authored-By: Claude' --oneline
if ($left) { $left; throw "Trailer still present. Do NOT push. Reset to the backup ref." }
$left2 = git log --grep='Claude-Session' --oneline
if ($left2) { $left2; throw "Session trailer still present. Do NOT push." }
Write-Host "  clean" -ForegroundColor Green

Step "CHECK 2 - the code is byte-identical to before"
$diff = git diff backup/pre-coauthor-strip HEAD --stat
if ($diff) {
    $diff
    throw "The tree changed. That must not happen - only messages were edited. Do NOT push."
}
Write-Host "  identical - only commit messages changed" -ForegroundColor Green

Step "CHECK 3 - same number of commits, same authors"
Write-Host "  commits: $(git rev-list --count HEAD) (was $(git rev-list --count backup/pre-coauthor-strip))"
git --no-pager shortlog -sne HEAD | Out-Host

Step "CHECK 4 - Pragya's history is untouched"
$hers = git rev-parse "$BASE"
Write-Host "  $BASE and everything below it keeps its SHA: $hers" -ForegroundColor Green

Step "The rewritten commits"
git --no-pager log --oneline -10

# --- what is left to do -------------------------------------------------
Write-Host ""
Write-Host "=================================================" -ForegroundColor Green
Write-Host "Nothing has been pushed. Two commands left:" -ForegroundColor Green
Write-Host ""
Write-Host "    git push --force-with-lease origin main" -ForegroundColor White
Write-Host ""
Write-Host "Then, once GitHub looks right, drop the backup and the" -ForegroundColor Green
Write-Host "filter-branch leftovers:" -ForegroundColor Green
Write-Host ""
Write-Host "    git branch -D backup/pre-coauthor-strip" -ForegroundColor White
Write-Host "    git update-ref -d refs/original/refs/heads/main" -ForegroundColor White
Write-Host "    git reflog expire --expire=now --all" -ForegroundColor White
Write-Host "    git gc --prune=now" -ForegroundColor White
Write-Host ""
Write-Host "TELL PRAGYA BEFORE SHE PULLS. Her own commits are untouched," -ForegroundColor Yellow
Write-Host "but the nine on top of them have new SHAs, so a plain 'git pull'" -ForegroundColor Yellow
Write-Host "will try to merge the old and new versions of the same work." -ForegroundColor Yellow
