"""Diagnostic: dump the extracted DPDP Act text so the section regex can be
checked against reality. Run from the intelligence/ directory:

    python ..\\smoke\\dump_act.py
"""
import os
import re
import sys

sys.path.insert(0, os.getcwd())  # script lives elsewhere; imports come from CWD

from legal.dpdp_source import (  # noqa: E402
    DPDP_ACT_PDF_URLS,
    _ENACTING_FORMULA,
    _SECTION_RE,
    fetch_act_text,
)

out_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)))

for i, url in enumerate(DPDP_ACT_PDF_URLS):
    label = f"source{i}"
    print(f"\n=== {label}: {url}")
    try:
        text = fetch_act_text(url=url)
    except Exception as exc:
        print(f"    FAILED: {exc}")
        continue

    path = os.path.join(out_dir, f"dpdp_{label}.txt")
    with open(path, "w", encoding="utf-8") as f:
        f.write(text)
    print(f"    chars={len(text)}  written to {path}")

    idx = text.index(_ENACTING_FORMULA)
    body = text[idx:]
    print(f"    _SECTION_RE matches: {len(list(_SECTION_RE.finditer(body)))}")

    # A few looser probes, to show which shape the text actually uses
    probes = {
        "N. Title.—body      ": r"(?m)^\s*(\d{1,2})\.\s+([^.]+?)\.\s*[–—\-]+\s*",
        "N. (1) body         ": r"(?m)^\s*(\d{1,2})\.\s*\(1\)",
        "N. Title (own line) ": r"(?m)^\s*(\d{1,2})\.\s+([A-Z][^\n]{3,80})\s*$",
        "N.<space>anything   ": r"(?m)^\s*(\d{1,2})\.\s+\S",
        "any em/en dash      ": r"[–—]",
    }
    for name, pat in probes.items():
        print(f"      {name} -> {len(re.findall(pat, body))}")

    print("    ---- first 1200 chars after the enacting formula ----")
    print(body[:1200])
