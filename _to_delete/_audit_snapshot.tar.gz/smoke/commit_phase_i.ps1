# ============================================================
# Niam - Phase I commit (I.5 scan persistence, I.6 rate limits,
#                        deployment config)
#
#   cd D:\niam\Niam
#   Remove-Item .git\index.lock -ErrorAction SilentlyContinue
#   powershell -ExecutionPolicy Bypass -File .\smoke\commit_phase_i.ps1
#
# One commit this time - it is one piece of work. Does NOT push.
# ============================================================

$ErrorActionPreference = 'Stop'

if (-not (Test-Path .git))          { throw "Not a git repo. cd to D:\niam\Niam first." }
if (Test-Path .git\index.lock)      { throw "Stale .git\index.lock - run: Remove-Item .git\index.lock" }
if (-not (Test-Path smoke\msg_i.txt)) { throw "smoke\msg_i.txt missing." }
if ((git diff --cached --name-only).Count -gt 0) {
    throw "Something is already staged. Run 'git reset' first."
}

git add -A -- `
  backend/app/services/scan_store.py `
  backend/app/services/scan_service.py `
  backend/app/api/v1/endpoints/scan.py `
  backend/app/api/v1/endpoints/webhook.py `
  backend/app/core/config.py `
  intelligence/graph/schema.py `
  frontend/src/hooks/useScan.ts `
  frontend/src/components/repositories/ScanPanel.tsx `
  frontend/src/services/api/client.ts `
  render.yaml `
  frontend/vercel.json

git --no-pager diff --cached --stat
git commit -F smoke\msg_i.txt | Out-Host

Write-Host ""
Write-Host "=================== RESULT ===================" -ForegroundColor Green
git --no-pager log --oneline -3
Write-Host ""
Write-Host "Still uncommitted (should be empty or only smoke\ .vscode\):" -ForegroundColor Yellow
git status --porcelain
Write-Host ""
Write-Host "Nothing pushed yet. When that looks right:" -ForegroundColor Green
Write-Host "    git push origin main" -ForegroundColor White
