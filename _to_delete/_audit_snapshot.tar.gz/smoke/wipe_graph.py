"""
Wipe a Niam graph so it can be rebuilt through the per-user path.

Everything written before the tenancy change is unowned: no owner_id, no
scoped uid. Those nodes match no account's queries, so they are invisible
in the app while still occupying an AuraDB Free budget and confusing
anyone who opens the Neo4j browser. A re-scan was chosen over a
migration, and this is the "before" half of it.

    python smoke/wipe_graph.py                          # report only
    python smoke/wipe_graph.py --yes                    # wipe EVERY account
    python smoke/wipe_graph.py --yes --users            # ...and the accounts
    python smoke/wipe_graph.py --owner me@x.com --yes   # wipe ONE account

--owner is the safe one, and the one you want most of the time: it deletes
that account's subgraph and leaves every other account, and the shared
DPDP Act, untouched. It is what makes "reset my test account and scan
again" something you can do on any database, including the one holding
real data.

Without --owner this is instance-wide and deletes the Act too, so the next
run has to re-extract it -- about two minutes and a Gemini call per
section.

By default :User and :GithubConnection are KEPT. You almost never want to
delete the account you are about to scan as -- and the CLIs resolve
--owner against :User, so wiping accounts means signing up again before
anything can be loaded.

Reads NEO4J_* from the environment like every other CLI here. It wipes
whatever NEO4J_URI points at and does not choose for you: check the
banner it prints before answering.
"""

import argparse
import logging
import os
import sys

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _ROOT)
os.environ.setdefault("NIAM_ENV_PATH", os.path.join(_ROOT, "backend", ".env"))

from graph.neo4j_client import Neo4jClient  # noqa: E402

# "The label `Scan` does not exist in database" is the expected answer
# when counting a label on a graph you are about to empty. Left on, one
# such block per label buries the counts you are meant to be reading.
logging.getLogger("neo4j.notifications").setLevel(logging.ERROR)

# Ordered widest-first. DETACH DELETE takes the relationships with it.
COMPLIANCE_LABELS = [
    "Gap",
    "RemediationDraft",
    "PullRequest",
    "Scan",
    "PolicyDocument",
    "Vendor",
    "DataType",
    "System",
    "DPDPClause",
]
# Identity moved to Postgres. :User, :GithubConnection and
# :GithubOAuthState are not written to the graph any more, and
# graph/cleanup_migrated.py deleted the ones that were -- so there is
# nothing here for a --users flag to delete, and offering one would
# suggest this script can clear an account when it cannot.
#
# An account's own rows (scans, audit log, GitHub connection) are cleared
# from inside the app: Settings -> Delete all findings, which
# workspace_service.reset_account_data() applies to BOTH databases. Do
# that per account BEFORE the instance-wide wipe below, or the Postgres
# rows outlive the graph they point at.
ACCOUNT_LABELS: list[str] = []

# Per-owner deletion. :RemediationDraft has no owner of its own -- it is
# only ever reached through the :Gap that owns it -- so it is deleted by
# traversal rather than by label. :DPDPClause is never deleted here: the
# Act is shared reference data and wiping it for one account would take it
# from everybody.
OWNED_BY_OWNER_ID = [
    "Gap",
    "PullRequest",
    "PolicyDocument",
    "Vendor",
    "DataType",
    "System",
    "GithubConnection",
]

COUNT_OWNED = "MATCH (n:{label} {{owner_id: $owner}}) RETURN count(n) AS c"
DELETE_OWNED = """
MATCH (n:{label} {{owner_id: $owner}})
WITH n LIMIT $batch
DETACH DELETE n
RETURN count(*) AS deleted
"""

# :Scan spells its owner user_id, because it predates the tenancy work and
# the property is part of the rate limiter's index.
COUNT_SCANS = "MATCH (s:Scan {user_id: $owner}) RETURN count(s) AS c"
DELETE_SCANS = """
MATCH (s:Scan {user_id: $owner})
WITH s LIMIT $batch
DETACH DELETE s
RETURN count(*) AS deleted
"""

# Drafts hanging off this owner's gaps. Run BEFORE the gaps are deleted,
# or the traversal has nothing to walk and they are orphaned forever.
COUNT_DRAFTS = """
MATCH (:Gap {owner_id: $owner})-[:HAS_DRAFT]->(rd:RemediationDraft)
RETURN count(DISTINCT rd) AS c
"""
DELETE_DRAFTS = """
MATCH (:Gap {owner_id: $owner})-[:HAS_DRAFT]->(rd:RemediationDraft)
WITH DISTINCT rd LIMIT $batch
DETACH DELETE rd
RETURN count(*) AS deleted
"""

COUNT = "MATCH (n:{label}) RETURN count(n) AS c"

# Deleted in bounded batches, looped from Python, rather than with
# `CALL {{ ... }} IN TRANSACTIONS`. That construct is the usual answer for
# a large delete, but it only runs in an IMPLICIT (auto-commit)
# transaction, and Neo4jClient.run_write uses session.execute_write, which
# opens an explicit one:
#
#   Neo.DatabaseError.Transaction.TransactionStartFailed
#   A query with 'CALL { ... } IN TRANSACTIONS' can only be executed in an
#   implicit transaction, but tried to execute in an explicit transaction.
#
# Looping a LIMIT-ed delete gets the same memory safety without needing a
# second execution path in the shared client.
BATCH = 1000
DELETE = """
MATCH (n:{label})
WITH n LIMIT $batch
DETACH DELETE n
RETURN count(*) AS deleted
"""


def _delete_all(client, query: str, params: dict | None = None) -> int:
    """Run a LIMIT-ed delete until it stops finding anything."""
    params = dict(params or {})
    params["batch"] = BATCH
    removed = 0
    while True:
        rows = client.run_write(query, params)
        n = rows[0]["deleted"] if rows else 0
        removed += n
        if n < BATCH:
            return removed


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--yes", action="store_true", help="actually delete")
    parser.add_argument(
        "--owner",
        help=(
            "delete only this account's subgraph (user id or email). "
            "Leaves other accounts and the shared DPDP Act alone."
        ),
    )
    parser.add_argument(
        "--users",
        action="store_true",
        help=(
            "accepted but does nothing: identity lives in Postgres now. "
            "Clear an account from Settings -> Delete all findings."
        ),
    )
    args = parser.parse_args()

    client = Neo4jClient()
    try:
        uri = os.getenv("NEO4J_URI", "(unset)")
        print(f"\n  Target: {uri}")
        if "localhost" not in uri and "127.0.0.1" not in uri:
            print("  ** This is NOT a local database. **")

        if args.owner:
            return _wipe_one_owner(client, args)
        return _wipe_everything(client, args)
    finally:
        client.close()
    return 0


def _wipe_one_owner(client, args) -> int:
    from graph.owner import UnknownOwner, resolve_owner_id

    try:
        owner = resolve_owner_id(args.owner)
    except UnknownOwner as exc:
        print(f"\nERROR: {exc}")
        return 1

    print(f"  Account: {args.owner}  ->  {owner}")
    print("  (other accounts and the shared DPDP Act are not touched)\n")

    counts = [
        ("RemediationDraft", COUNT_DRAFTS, DELETE_DRAFTS),
        ("Scan", COUNT_SCANS, DELETE_SCANS),
    ] + [
        (
            label,
            COUNT_OWNED.format(label=label),
            DELETE_OWNED.format(label=label),
        )
        for label in OWNED_BY_OWNER_ID
    ]

    total = 0
    for label, count_q, _ in counts:
        rows = client.run_read(count_q, {"owner": owner})
        n = rows[0]["c"] if rows else 0
        total += n
        print(f"    {label:<20} {n:>7}")
    print(f"\n    {'TOTAL':<20} {total:>7}\n")

    if not args.yes:
        print("Report only. Re-run with --yes to delete.")
        return 0
    if total == 0:
        print("Nothing to delete for this account.")
        return 0

    # Drafts first: they are reached through the gaps, so deleting the
    # gaps first would strand them with nothing pointing at them.
    for label, _, delete_q in counts:
        n = _delete_all(client, delete_q, {"owner": owner})
        print(f"  deleted :{label:<20} {n:>7}")

    print(
        "\nDone. That account is now exactly as it was the moment it "
        "signed up:\nsign in, connect GitHub, and scan."
    )
    return 0


def _wipe_everything(client, args) -> int:
    labels = COMPLIANCE_LABELS + (ACCOUNT_LABELS if args.users else [])
    print("  Scope: the GRAPH -- every account's findings, plus the")
    print("         shared DPDP Act. Postgres is NOT touched.")
    print("  (--owner EMAIL wipes one account's graph instead)\n")

    total = 0
    for label in labels:
        rows = client.run_read(COUNT.format(label=label))
        count = rows[0]["c"] if rows else 0
        total += count
        print(f"    {label:<20} {count:>7}")
    kept = "  (accounts live in Postgres; see ACCOUNT_LABELS)"
    print(f"\n    {'TOTAL':<20} {total:>7}{kept}\n")

    if not args.yes:
        print("Report only. Re-run with --yes to delete.")
        return 0
    if total == 0:
        print("Nothing to delete.")
        return 0

    for label in labels:
        n = _delete_all(client, DELETE.format(label=label))
        print(f"  deleted :{label:<20} {n:>7}")

    print("\nDone. Rebuild the shared reference data, from intelligence/:")
    print("    python -m graph.apply_schema --owner <you>")
    print("    python -m legal.load_dpdp_clauses --yes")
    print("\n...then sign in and scan from the Repositories page.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
