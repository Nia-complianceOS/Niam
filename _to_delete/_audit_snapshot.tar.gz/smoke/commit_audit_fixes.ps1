# ============================================================
# Niam - post-Supabase audit fixes. Two commits.
#
#   cd D:\niam\Niam
#   Remove-Item .git\index.lock -ErrorAction SilentlyContinue
#   powershell -ExecutionPolicy Bypass -File .\smoke\commit_audit_fixes.ps1
#
# Stops before pushing.
# ============================================================
$ErrorActionPreference = 'Stop'
function Step($n,$t){ Write-Host ""; Write-Host "== $n : $t" -ForegroundColor Cyan }

if (-not (Test-Path .git))     { throw "Not a git repo. cd to D:\niam\Niam first." }
if (Test-Path .git\index.lock) { throw "Stale lock - run: Remove-Item .git\index.lock" }
if ((git diff --cached --name-only).Count -gt 0) { throw "Something is already staged. Run 'git reset'." }

Step "1/2" "boot, deploy, and the browser"
git add -A -- `
  backend/requirements.txt `
  render.yaml `
  backend/package.json backend/package-lock.json `
  intelligence/package.json intelligence/package-lock.json `
  frontend/package.json frontend/package-lock.json `
  frontend/.env.example `
  frontend/src/lib/supabase.ts
git --no-pager diff --cached --stat
git commit -F smoke\msg_a1.txt | Out-Host

Step "2/2" "accounts live in Postgres"
git add -A -- `
  intelligence/graph/owner.py `
  intelligence/pyproject.toml `
  intelligence/graph/run_scan_and_write.py `
  intelligence/legal/load_policies.py `
  intelligence/reconciliation/run.py `
  intelligence/reconciliation/run_reconciliation.py `
  intelligence/retrieval/query_cli.py `
  backend/migrations
git --no-pager diff --cached --stat
git commit -F smoke\msg_a2.txt | Out-Host

Write-Host ""
Write-Host "=================== RESULT ===================" -ForegroundColor Green
git --no-pager log --oneline -4
Write-Host ""
Write-Host "Still uncommitted (should be empty, or only smoke\ .vscode\):" -ForegroundColor Yellow
git status --porcelain
Write-Host ""
Write-Host "Nothing pushed. When that looks right:" -ForegroundColor Green
Write-Host "    git push origin main" -ForegroundColor White
