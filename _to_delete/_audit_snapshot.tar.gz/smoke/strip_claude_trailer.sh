#!/bin/sh
# Reads a commit message on stdin, writes it back without the two
# Claude trailers, and without the blank line they left behind.
#
# Two passes on purpose. Doing both in one sed script does not work: the
# blank-line loop uses N, which pulls the next line into the pattern
# space, and after that the trailer no longer sits at the start of the
# pattern space for /^Co-Authored-By:/ to match. The deletion has to
# finish before the trailing-blank cleanup begins.
sed '/^Co-Authored-By: Claude/,$d' | sed -e :a -e '/^$/{$d;N;ba' -e '}'
