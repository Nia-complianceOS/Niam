# ============================================================
# Niam - commit batch 3 (multi-tenancy, per-user GitHub, workspace)
#
#   cd D:\niam\Niam
#   Remove-Item .git\index.lock -ErrorAction SilentlyContinue
#   powershell -ExecutionPolicy Bypass -File .\smoke\commit_batch3.ps1
#
# Six commits. Stops before pushing.
# ============================================================

$ErrorActionPreference = 'Stop'
function Step($n, $t) { Write-Host ""; Write-Host "== $n : $t" -ForegroundColor Cyan }

if (-not (Test-Path .git))     { throw "Not a git repo. cd to D:\niam\Niam first." }
if (Test-Path .git\index.lock) { throw "Stale .git\index.lock - run: Remove-Item .git\index.lock" }
foreach ($m in 1..6) {
    if (-not (Test-Path "smoke\msg_t$m.txt")) { throw "smoke\msg_t$m.txt missing." }
}
if ((git diff --cached --name-only).Count -gt 0) {
    throw "Something is already staged. Run 'git reset' first."
}

$before = (git status --porcelain).Count
Write-Host "Branch: $((git rev-parse --abbrev-ref HEAD).Trim())   changed paths: $before" -ForegroundColor Yellow

# --- 1/6  the intelligence package ---------------------------------------
Step "1/6" "tenancy - the graph gets an owner"
git add -A -- intelligence
git --no-pager diff --cached --stat
git commit -F smoke\msg_t1.txt | Out-Host

# --- 2/6  backend read path ----------------------------------------------
Step "2/6" "tenancy - the backend serves one account"
git add -A -- `
  backend/app/services/gap_service.py `
  backend/app/services/graph_service.py `
  backend/app/services/dashboard_service.py `
  backend/app/services/scan_store.py `
  backend/app/api/v1/endpoints/dashboard.py `
  backend/app/api/v1/endpoints/graph.py `
  backend/app/api/v1/endpoints/gaps.py `
  backend/app/api/v1/endpoints/compliance.py `
  backend/tests
git --no-pager diff --cached --stat
git commit -F smoke\msg_t2.txt | Out-Host

# --- 3/6  per-user GitHub -------------------------------------------------
Step "3/6" "github - each user connects their own account"
git add -A -- `
  backend/app/core/config.py `
  backend/app/core/crypto.py `
  backend/app/services/github_service.py `
  backend/app/services/github_identity.py `
  backend/app/api/v1/endpoints/github.py `
  backend/app/api/v1/endpoints/github_oauth.py `
  backend/app/api/v1/endpoints/webhook.py `
  backend/app/api/v1/router.py `
  backend/requirements.txt `
  render.yaml
git --no-pager diff --cached --stat
git commit -F smoke\msg_t3.txt | Out-Host

# --- 4/6  the scan pipeline ----------------------------------------------
Step "4/6" "scan - legal documents, one system per repository"
git add -A -- `
  backend/app/services/scan_service.py `
  backend/app/api/v1/endpoints/scan.py
git --no-pager diff --cached --stat
git commit -F smoke\msg_t4.txt | Out-Host

# --- 5/6  workspace management -------------------------------------------
Step "5/6" "workspace - a scanned repository can be removed"
git add -A -- `
  backend/app/services/workspace_service.py `
  backend/app/api/v1/endpoints/workspace.py
git --no-pager diff --cached --stat
git commit -F smoke\msg_t5.txt | Out-Host

# --- 6/6  the frontend ----------------------------------------------------
Step "6/6" "ui - one account's data, and a way in"
git add -A -- frontend
git --no-pager diff --cached --stat
git commit -F smoke\msg_t6.txt | Out-Host

# --- report ---------------------------------------------------------------
Write-Host ""
Write-Host "=================== RESULT ===================" -ForegroundColor Green
git --no-pager log --oneline -8
Write-Host ""
Write-Host "Still uncommitted (should be empty, or only smoke\ .vscode\):" -ForegroundColor Yellow
git status --porcelain
Write-Host ""
Write-Host "Nothing pushed. When that looks right:" -ForegroundColor Green
Write-Host "    git push origin main" -ForegroundColor White
