"""
smoke/diagnose_gaps.py -- why did the reconciler write no gaps?

Run from intelligence/, with the smoke env vars set:

    python ..\smoke\diagnose_gaps.py --system niam-smoke

Prints exactly what Reconciler.find_and_write_gaps() sees for each data
type -- vendors, the clause set AFTER the retriever merges in the
general-purpose "other_personal_data" clauses, how many of those are in
force, and the verdict classify_gap() returns. Writes nothing.
"""

import argparse
import os
import sys
from pathlib import Path

# `python -m pkg.mod` puts the working directory on sys.path; running a
# script by path puts the SCRIPT's directory there instead. This file
# lives in smoke/ but imports the intelligence packages, so without this
# it dies on `No module named 'graph'` no matter where you run it from.
_INTELLIGENCE = Path(__file__).resolve().parents[1] / "intelligence"
for _candidate in (os.getcwd(), str(_INTELLIGENCE)):
    if _candidate not in sys.path:
        sys.path.insert(0, _candidate)

from graph.neo4j_client import Neo4jClient  # noqa: E402
from graph.schema import DEFAULT_SYSTEM_NAME  # noqa: E402
from legal.commencement import imposes_data_obligation  # noqa: E402
from reconciliation.reconciler import classify_gap, _section_of  # noqa: E402
from retrieval.dpdp_retrieval import DPDPRetriever  # noqa: E402
from retrieval.queries import VENDORS_FOR_DATA_TYPE  # noqa: E402


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--system", default=None)
    args = parser.parse_args()

    client = Neo4jClient()
    print(f"[0] connected: {client.uri if hasattr(client, 'uri') else '?'}")

    # --- 1. which systems exist, and do any collect anything? -----------
    rows = client.run_read(
        "MATCH (s:System) "
        "OPTIONAL MATCH (s)-[:COLLECTS]->(d:DataType) "
        "RETURN s.name AS name, count(d) AS data_types"
    )
    print("\n[1] :System nodes in this database")
    for row in rows:
        print(f"    {row['name']!r}: collects {row['data_types']} data type(s)")
    if not rows:
        print("    NONE. The scan did not write a System node.")
        return

    system = args.system or DEFAULT_SYSTEM_NAME
    print(f"\n[2] reconciling as system = {system!r}")
    names = [r["name"] for r in rows]
    if system not in names:
        print(f"    *** MISMATCH: no System named {system!r}. ***")
        print(f"    The graph has {names}.")
        print("    clauses_for_system() returns {} and the reconciler")
        print("    writes zero gaps without raising anything.")
        return

    # --- 3. which clauses are in force, and what do they govern? --------
    in_force_rows = client.run_read(
        "MATCH (c:DPDPClause) WHERE c.status = 'in_force' "
        "OPTIONAL MATCH (d:DataType)-[:GOVERNED_BY]->(c) "
        "RETURN c.clause_id AS clause_id, c.title AS title, "
        "collect(d.name) AS governs ORDER BY clause_id"
    )
    print(f"\n[3] in-force clauses ({len(in_force_rows)})")
    general_in_force = []
    for row in in_force_rows:
        governs = [g for g in row["governs"] if g]
        print(f"    {row['clause_id']}: {row['title']}")
        print(f"        governs: {governs or '(nothing directly)'}")
        if DPDPRetriever.GENERAL_DATA_TYPE in governs:
            general_in_force.append(row["clause_id"])

    # --- 4. per data type, exactly what classify_gap() is handed --------
    retriever = DPDPRetriever(client)
    by_data_type = retriever.clauses_for_system(system)

    if not by_data_type:
        print("\n[4] clauses_for_system() returned NOTHING for this system.")
        return

    print(f"\n[4] per data type ({len(by_data_type)}), as the reconciler sees it")
    print(
        f"    {'data_type':<26}{'vendors':>8}{'clauses':>9}"
        f"{'oblig':>7}{'in_force':>10}  verdict"
    )
    verdicts = {}
    for data_type, clauses in sorted(by_data_type.items()):
        vendor_rows = client.run_read(
            VENDORS_FOR_DATA_TYPE, {"data_type": data_type}
        )
        vendors = vendor_rows[0]["vendors"] if vendor_rows else []
        # `oblig` is the subset that actually obliges a Data Fiduciary,
        # and `in_force` counts only those -- the regulator-power sections
        # that used to mask every gap are excluded from both.
        obligations = [
            c for c in clauses if imposes_data_obligation(_section_of(c))
        ]
        in_force = [c for c in obligations if c["status"] == "in_force"]
        severity, kind = classify_gap(vendors, clauses)
        verdict = f"{severity}/{kind}" if kind else "NO GAP"
        verdicts[verdict] = verdicts.get(verdict, 0) + 1
        print(
            f"    {data_type:<26}{len(vendors):>8}{len(clauses):>9}"
            f"{len(obligations):>7}{len(in_force):>10}  {verdict}"
        )

    print("\n[5] verdict counts")
    for verdict, count in sorted(verdicts.items()):
        print(f"    {verdict}: {count}")

    if set(verdicts) == {"NO GAP"}:
        print("\n    *** Every data type classified as NO GAP. ***")
        if general_in_force:
            print(
                "    Cause: clause(s) "
                + ", ".join(general_in_force)
                + " are tagged 'other_personal_data' AND in force."
            )
            print(
                "    DPDPRetriever merges general-purpose clauses into EVERY\n"
                "    data type, so every data type inherits an in-force clause,\n"
                "    and classify_gap() treats 'has any in-force clause' as\n"
                "    fully governed. One administrative section in force\n"
                "    therefore silences the entire gap engine."
            )
        else:
            print("    No general in-force clause, so the cause is elsewhere.")

    client.close()


if __name__ == "__main__":
    sys.exit(main())
