# Tenancy contract — read this before changing any query

Every account gets its own subgraph. Before this change nothing in the read
path filtered by anything (`MATCH (g:Gap)`, `MATCH (n) WHERE n:System OR ...`),
so two accounts on one instance saw one merged graph.

## The rules

1. **Owned labels** carry two properties:
   - `owner_id` — a plain string property, for filtering. Indexed.
   - `uid` — the MERGE key, `"<owner_id>:<name>"`, produced ONLY by
     `graph.schema.scoped_uid(owner_id, name)`. Never build it in Cypher.

   Owned labels: `:System`, `:DataType`, `:Vendor`, `:PolicyDocument`
   (owner-prefixed `id`, plus `owner_id`), `:Gap` (owner-prefixed `id`, plus
   `owner_id`), `:Scan` (`user_id`), `:PullRequest` (`owner_id`).

2. **`:DPDPClause` is NOT owned.** The Act is the same law for everyone and
   costs a Gemini call per section to extract. It carries `data_types` — an
   array of taxonomy names it governs. The per-user edge
   `(:DataType)-[:GOVERNED_BY]->(:DPDPClause)` is materialised by
   `GraphWriter.link_clauses()` after that user's data types exist.

3. **`:RemediationDraft` is not owned** — it is only ever reached through the
   `:Gap` that owns it, and that Gap is filtered.

4. **Single-property scoped key, never a composite constraint.** Composite
   uniqueness needs Neo4j Enterprise; the verification rig runs the Community
   image (`neo4j:5`). A constraint that exists on Aura and not on the rig is
   worse than none — it means the tests prove something production does not
   enforce.

## What every read query must do

Filter on `owner_id` at the point the owned node enters the pattern:

```cypher
-- WRONG: reads every account's data
MATCH (g:Gap)
MATCH (d:DataType {name: $data_type})

-- RIGHT
MATCH (g:Gap {owner_id: $owner_id})
MATCH (d:DataType {owner_id: $owner_id, name: $data_type})
```

Anchoring on the user's own `:System` and traversing outward is also correct,
and is preferred where the pattern allows it — a traversal that starts inside
one account cannot leave it.

`:DPDPClause` is matched WITHOUT an owner filter. Everything else has one.

## Signatures

- `GraphWriter(client=None, system_name=..., owner_id=...)` — `owner_id`
  required, raises `ValueError` without it.
- `Reconciler(client=None, system_name=..., owner_id=...)` — same rule.
- `DPDPRetriever` methods take `owner_id`.
- Backend services take `owner_id: str` as their first argument, sourced from
  `Depends(require_auth)`. No service reads the graph without one.

## The failure mode to design against

A forgotten filter does not raise. It silently shows one user another user's
compliance findings — vendor names, source file paths, commit SHAs from a
private repository. Treat a missing `owner_id` as a data breach, not a bug.
Where a helper can require it (like `scoped_uid`), it raises rather than
defaulting.
