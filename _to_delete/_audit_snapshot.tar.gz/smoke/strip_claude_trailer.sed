/^Co-Authored-By: Claude/,$d
:a
/^$/{$d;N;ba
}
