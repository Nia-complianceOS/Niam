readme: a setup someone else can actually follow

The old "Getting started" was five code blocks and assumed you already
knew what they were for. It skipped the venv activation failure everyone
hits on Windows, said nothing about where the Neo4j values come from,
listed the environment keys without saying which are required, and left
out policy loading entirely -- the step whose absence is silent, because
the reconciler skips disclosure checks rather than reporting every data
type as undisclosed.

Now eight numbered steps from `git clone` to a signed-up account, with
PowerShell and POSIX commands side by side, a check after each install
that would otherwise fail three steps later, and a troubleshooting table
of the errors this project actually produces: the PowerShell execution
policy, `curl` being Invoke-WebRequest, GitHub answering 404 rather than
403 for a repo the token cannot see, and a paused Aura instance needing
an API restart because the driver is cached for the life of the process.

Two claims in the README were also false as of this week. "Authentication
is a development bypass" and "scan state is in memory" both described the
code before I.0 and I.5; and the note on the duplicated backend/ tree
still called its removal a pending task, three commits after it was
removed. A README that is wrong about the parts anyone can verify is
worse than a short one, particularly on a repository linked from a CV.

Known limitations rewritten to the ones that are true: coarse clause
tagging, a classifier that under-reports by design, disclosure findings
that need the documents loaded first, DPDP only, and the fact that this
drafts rather than decides.
