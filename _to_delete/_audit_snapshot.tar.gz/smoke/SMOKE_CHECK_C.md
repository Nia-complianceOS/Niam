# Smoke Check C — step by step, per terminal

Written 2026-08-31, after the Phase C leftovers were fixed
(`score_delta`, `mapped_controls`, `affected_systems`, the `"0%"` fallback).

Terminals, per `KAMRAN_RUNBOOK.md`. **Smoke Check C does not need T1 or T2** —
the demo stack can stay closed. You need four windows:

| # | Title | Purpose | Talks to |
|---|---|---|---|
| **T3** | `SMOKE-API` | backend on :8001 | local Neo4j |
| **T4** | `SMOKE-CLI` | intelligence CLIs | local Neo4j |
| **T5** | `CHECKS` | docker + Aura reads | **Aura — must stay clean** |
| **T6** | `SMOKE-UI` | frontend on :5174 | :8001 |

**Close every PowerShell window you have open first.** A stale window carries a
stale PATH and possibly leftover `$env:NEO4J_*`.

---

## 0 — Pre-flight (one fresh window)

```powershell
cd D:\niamm\Niam
.\backend\venv\Scripts\Activate.ps1
.\smoke\preflight.ps1
```
Need: `python` under `backend\venv`, `deps: ok`, `neo4j vars: clean`,
`docker: engine up`. If `envfile : NOT FOUND`, re-run it from `intelligence\`.
Anything else wrong → the table in the runbook's Step 0.

---

## 1 — T5 (CHECKS): start the smoke database

```powershell
$Host.UI.RawUI.WindowTitle = "CHECKS"
if ($env:NEO4J_URI) { Write-Host "CONTAMINATED - close this window" -ForegroundColor Red } else { Write-Host "clean - safe for Aura" -ForegroundColor Green }

cd D:\niamm\Niam
docker compose up -d neo4j
docker ps
```

Wait for Bolt to actually accept connections — a fixed `Start-Sleep` is not
enough, and querying too early returns a genuine "Graph unreachable" that looks
exactly like the A3 bug:

```powershell
foreach ($i in 1..40) {
  try { Invoke-WebRequest http://localhost:7474 -UseBasicParsing -TimeoutSec 2 | Out-Null
        Write-Host "neo4j ready" -ForegroundColor Green; break }
  catch { Start-Sleep -Seconds 3 }
}
```

---

## 2 — T4 (SMOKE-CLI): populate the smoke graph

The smoke DB was wiped for the A3 regression test, so it is empty.

```powershell
$Host.UI.RawUI.WindowTitle = "SMOKE-CLI"
cd D:\niamm\Niam\intelligence
..\backend\venv\Scripts\Activate.ps1

$env:NEO4J_URI      = "bolt://localhost:7687"
$env:NEO4J_USERNAME = "neo4j"
$env:NEO4J_USER     = "neo4j"
$env:NEO4J_PASSWORD = "testpassword"
Write-Host "SMOKE MODE - local Neo4j only" -ForegroundColor Yellow
```

Then, in order:

```powershell
python -m graph.apply_schema
python -m legal.load_dpdp_clauses --yes
python -m graph.run_scan_and_write niacomplianceos/niam-smoke-repo --system niam-smoke --yes
python -m reconciliation.run_reconciliation --system niam-smoke --yes
```

- `load_dpdp_clauses` reads `legal\.cache\dpdp_clauses.json` — instant, no
  Gemini calls, no live URL needed.
- The scan is the only slow step (~71 candidate lines, ~4 Gemini calls).
- **The reconciliation step is required for Smoke Check C**, not optional:
  the Audit Trail page is now built from `:Gap` nodes, so with no gaps it is
  empty and you cannot tell "correctly empty" from "still broken".
- A 404 on the scan is a token/owner problem, not a missing repo:
  `python ..\smoke\check_repo_access.py niacomplianceos/niam-smoke-repo`.

---

## 3 — T3 (SMOKE-API): backend on :8001

```powershell
$Host.UI.RawUI.WindowTitle = "SMOKE-API"
cd D:\niamm\Niam\backend
.\venv\Scripts\Activate.ps1

$env:NEO4J_URI      = "bolt://localhost:7687"
$env:NEO4J_USERNAME = "neo4j"
$env:NEO4J_USER     = "neo4j"
$env:NEO4J_PASSWORD = "testpassword"
Write-Host "SMOKE MODE - local Neo4j only" -ForegroundColor Yellow

uvicorn app.main:app --reload --port 8001 --host 127.0.0.1
```

`--reload` so the Phase C edits are picked up without a restart. Watch the
startup line — it should log the `AUTH BYPASS ACTIVE` warning (that means
`APP_ENV=development`, which is what C's walkthrough needs).

---

## 4 — T6 (SMOKE-UI): frontend on :5174

```powershell
$Host.UI.RawUI.WindowTitle = "SMOKE-UI"
cd D:\niamm\Niam\frontend
$env:VITE_API_BASE_URL = "http://localhost:8001/api/v1"
npm run dev -- --port 5174
```

Open <http://localhost:5174>. **Then prove it hit the right API:** F12 →
Network → reload → requests must go to **:8001**, not :8000. If they go to
:8000, Vite did not pick up the shell variable — create
`frontend\.env.local` with `VITE_API_BASE_URL=http://localhost:8001/api/v1`,
restart, and **delete that file when you are done**.

---

## 5 — Walkthrough #1: populated

`USE_MOCKS=false`. Open all nine pages. For every number, say out loud which
node or endpoint produced it.

| Page | Expected |
|---|---|
| Dashboard | 5 real cards. Vendor card reads **"Vendors detected"**. No timeline, no commit feed (both empty by design) |
| Compliance Graph | nodes visible |
| Repositories | the repo input + **Start scan** button; empty repo list below it |
| Vendors | header `N detected · M connected`; rows badged **"Detected in code"** — expect **0 connected** on the smoke rig (no vendor-API ingestion has run there) |
| Regulations | DPDP with a real score; countdown to **13 Nov 2026**; **Affected Systems** shows `niam-smoke`; **Mapped Controls** shows `—` |
| Policies | empty state, **not** a red 503 |
| Pull Requests | empty state, **not** a red 503 |
| Audit Trail | real `gap_detected` events, actor `Reconciler · <vendor>`. No "Priya S." |
| Settings | read-only health panel only |

New since the last pass — check these specifically:

- **Mapped Controls must read `—`**, not "Purpose limitation / Consent capture /
  Data minimisation". Those three were hardcoded.
- **Affected Systems must read `niam-smoke`**, not "Signup Form / Database / AWS".
- Nothing anywhere shows a `-4%` movement (`score_delta` is gone).

---

## 6 — Walkthrough #2: wiped

**T5:**
```powershell
cd D:\niamm\Niam
docker compose down -v
docker compose up -d neo4j
foreach ($i in 1..40) {
  try { Invoke-WebRequest http://localhost:7474 -UseBasicParsing -TimeoutSec 2 | Out-Null
        Write-Host "neo4j ready" -ForegroundColor Green; break }
  catch { Start-Sleep -Seconds 3 }
}
```

Reload <http://localhost:5174> and walk the nine pages again.

| Page | Expected on the wiped DB |
|---|---|
| Dashboard | **zeros**, not `—  Graph unreachable`. Score card `—` / "No data types mapped yet" |
| Compliance Graph | "No graph data yet" |
| Repositories | scan input still there, empty list |
| Vendors | "No vendors connected yet" |
| Regulations | score `—`; Missing Requirements / Affected Systems / Mapped Controls all `—` |
| Policies, Pull Requests, Audit Trail | empty states |
| Settings | health panel, Neo4j shown as reachable (the DB is up, just empty) |

**Pass condition: no number appears anywhere.** Anything still showing is
hardcoded — tell me the page and I will find it.

---

## 7 — Teardown and the Aura check

**T5 (clean window — verify again before running this):**
```powershell
if ($env:NEO4J_URI) { Write-Host "CONTAMINATED - close this window" -ForegroundColor Red } else { Write-Host "clean" -ForegroundColor Green }
cd D:\niamm\Niam\intelligence
..\backend\venv\Scripts\Activate.ps1
Compare-Object (Get-Content ..\smoke\graph_baseline.txt) (python -m retrieval.query_cli summary)
```

`Compare-Object` printing **nothing** is the pass. Baseline at handoff:
`systems 1 · data_types 22 · vendors 13 · clauses 17 · in_force 2 · ungoverned 18`.

If the numbers moved and you only ran smoke commands, a `$env:NEO4J_*` leaked
into a window that talks to Aura. Stop and find it before any more work.

Leave the smoke container running if you are going straight on to Phase E;
otherwise `docker compose down -v`.

---

## Addendum — re-check after the graph / regulations fixes (2026-08-31)

Three bugs found during the first C walkthrough. Restart T3 if you started it
without `--reload`; Vite picks the frontend up on its own.

**Regulations page.** `Regulations.tsx` was a byte-for-byte copy of
`PullRequests.tsx`, so the route rendered the PR list and the accordion was
never mounted. It is now a real page. Check:

- The header reads **Regulations**, not "Pull Requests".
- A **Next commencement** block top-right: `13 Nov 2026` and a day count.
- Expanding DPDP shows three columns — Missing Requirements (real ungoverned
  data types), Mapped Controls (`—`), Affected Systems (`niam-smoke`).
- On the **wiped** DB: the empty state, or a `—` score. No numbers.

**Graph legend.** Every node used to come back `status: 'unknown'` (grey), and
clause nodes came back with a status the legend has no colour for, so they
rendered with no stroke at all. Status is now derived from the graph. Check:

- More than one colour on screen. On the smoke rig expect a lot of **red**
  (data types with no governing clause) — that is the honest reading of that
  fixture repo, not a bug.
- Hovering a node: **Legal Coverage** now says something real
  ("3 in-force clause(s) apply", "Collected, but no DPDP clause governs it",
  "2 of 6 data type(s) covered"), and **Collected Data** lists the actual
  data types for a System or Vendor.
- A vendor's colour must agree with its row on the Vendors page.

**Graph interaction.** Check all four:

- **Scroll** anywhere on the canvas zooms.
- **Drag the background** pans; the cursor turns into a grabbing hand.
- **Drag a node** moves that node and it stays where you put it.
- **Double-click**, or the ⤢ button top-right, frames every node — including
  the ones that were off the box. `+` / `−` step the zoom.
- The dashed edges now flow (disabled automatically if the OS is set to
  reduce motion).

Still open, deliberately: `/graph` has no `LIMIT` (roadmap E3). Pan and zoom
make a large graph navigable, they do not make it cheap to fetch.

---

# Smoke Check E — after Phase E (2026-08-31)

> ### ⚠️ `mock-token-123` no longer works (D1 closed, 2026-09-02)
> Every `curl.exe -H "Authorization: Bearer mock-token-123"` below is
> historical. The bypass is deleted; protected routes need a real JWT.
> To get one:
> ```powershell
> $body = '{"email":"you@example.com","password":"choose-one","name":"You"}'
> $r = curl.exe -s -X POST -H "Content-Type: application/json" -d $body http://localhost:8001/api/v1/auth/signup | ConvertFrom-Json
> $tok = $r.access_token
> curl.exe -s -H "Authorization: Bearer $tok" http://localhost:8001/api/v1/gaps
> ```
> Sign up once per database — the smoke container and Aura each hold their
> own `:User` nodes, and wiping the smoke DB deletes its accounts.

Everything below runs on the rig. **Wipe the smoke DB first** — E1 changes
what gets written, and a graph written by the old scanner has no commit
provenance to find.

**T5 (CHECKS):**
```powershell
cd D:\niamm\Niam
docker compose down -v
docker compose up -d neo4j
foreach ($i in 1..40) {
  try { Invoke-WebRequest http://localhost:7474 -UseBasicParsing -TimeoutSec 2 | Out-Null
        Write-Host "neo4j ready" -ForegroundColor Green; break }
  catch { Start-Sleep -Seconds 3 }
}
```

**T4 (SMOKE-CLI)** — S3 block set, from `D:\niamm\Niam\intelligence`:
```powershell
python -m graph.apply_schema
python -m legal.load_dpdp_clauses --yes
python -m graph.run_scan_and_write niacomplianceos/niam-smoke-repo --system niam-smoke --yes
python -m reconciliation.run_reconciliation --system niam-smoke --yes
```

The scan now prints `Scanning niacomplianceos/niam-smoke-repo at <12 hex chars>`.
If it prints `main`, `resolve_commit()` did not run and E1 will not land.

## E1 — gaps carry a real commit

Neo4j Browser (<http://localhost:7474>):
```cypher
MATCH (g:Gap)
RETURN g.id, g.source_commit_sha, g.source_commit_author,
       g.source_commit_repo, g.source_file
ORDER BY g.id LIMIT 10;
```
- `source_commit_sha` must be a **40-character hex sha**, not `main`.
- `source_commit_repo` must read `niacomplianceos/niam-smoke-repo`.
- `source_file` must be one of the six fixture files.

Then in the smoke UI (<http://localhost:5174>):

1. Dashboard shows a **Commits with compliance impact** panel — real sha
   (7 chars), real author, an `N gaps` count. No `nova-labs`, no `dev1`.
2. Click a commit → the **Compliance Impact** panel below fills in. This is
   the thing that has never worked: it matches gaps by
   `source_commit.sha`, and until now no gap had one.
3. **Generate fix** produces a draft.
4. **Open PR** — with `GITHUB_DRY_RUN=true` it should log its intent in T3
   against `niacomplianceos/niam-smoke-repo` and create nothing. Confirm no
   `niam/remediation/*` branch appears on GitHub.
   - A **503 "PR_ALLOWED_REPOS is not configured"** here is correct and
     fail-closed. To exercise the dry-run path, add
     `PR_ALLOWED_REPOS=niacomplianceos/niam-smoke-repo` to `backend\.env`
     yourself and restart T3.

## E4 — provenance stops growing

Run the scan a **second** time (T4), then:
```cypher
MATCH ()-[r:COLLECTS]->() RETURN size(r.sources) AS n ORDER BY n DESC LIMIT 5;
```
The numbers must **not** change between the first and second scan. They now
also carry a parallel key array — this should have the same length:
```cypher
MATCH ()-[r:COLLECTS]->() RETURN size(r.sources), size(r.source_keys) LIMIT 5;
```

## E5 — large files skipped

T4's scan log should print `Skipped N file(s) larger than 200000 bytes` when
any exist. On the smoke fixtures N is 0 — that is a pass, not a miss. The
check that matters is that the scan no longer pulls unbounded blobs.

## E2 / E6 — severity, kind, and framing

```cypher
MATCH (g:Gap) RETURN g.kind, g.severity, g.title ORDER BY g.kind;
```
- A `future_obligation` gap must be titled **"Future obligation: …"**, not
  "Ungoverned data sharing". Nearly the whole Act commences in 2026–27, so
  most gaps should read this way — that is the readiness framing, and it is
  what the data supports.
- `severity` and `kind` now come back on `GET /api/v1/gaps`:
  ```powershell
  curl.exe -s -H "Authorization: Bearer mock-token-123" http://localhost:8001/api/v1/gaps | Select-String "severity"
  ```

Verifier unit tests (T4, from `intelligence\`) — a not-yet-commenced clause
is no longer a verification failure:
```powershell
python -m pytest reasoning/test_verifier.py -q
```

## E3 — the graph query is bounded

```powershell
curl.exe -s -H "Authorization: Bearer mock-token-123" "http://localhost:8001/api/v1/graph?limit=5" | Select-String "truncated"
```
Expect `"truncated":true` with `total_nodes` well above 5. On the Graph page
a truncated view says so in amber under the canvas. Set `limit` low and
confirm the canvas still renders — no dangling edges, no D3 crash.

## Teardown and the Aura check

**T5 (clean window):**
```powershell
cd D:\niamm\Niam\intelligence
Compare-Object (Get-Content ..\smoke\graph_baseline.txt) (python -m retrieval.query_cli summary)
```
Nothing printed is the pass. Then:
```cypher
MATCH (g:Gap) RETURN g.id ORDER BY g.id
```
against **Aura** — no id may start with `gap-niam-smoke-`.

---

# Smoke Check F — the rename, and the clause-applicability fix

## Before you start: the rename changes two stored things

1. **localStorage keys** moved (`nia_user` → `niam_user`, `nia_sidebar_collapsed`
   → `niam_sidebar_collapsed`). You will be **logged out once**. Log back in;
   it will not happen again.
2. **`DEFAULT_SYSTEM_NAME` is now `niam-demo-system`** (F3). It is a graph
   KEY, so a scan against Aura would create a SECOND `:System` node and
   orphan every `COLLECTS` edge on the old one. You chose re-scan, so on
   **Aura**, before the next demo scan:
   ```cypher
   MATCH (s:System {name:'nia-demo-system'}) DETACH DELETE s;
   MATCH (n) WHERE NOT (n)--() DETACH DELETE n;
   ```
   Take an Aura snapshot first (runbook S5b). The smoke rig is unaffected —
   it passes `--system niam-smoke` explicitly.

## Frontend rebuild

**T2 / T6, after stopping the dev server** — `package.json` was renamed to
`niam-frontend`, so the lockfile needs regenerating:
```powershell
cd D:\niamm\Niam\frontend
npm install
npm run dev
```

## The grep

```powershell
cd D:\niamm\Niam
grep -ri "\bnia\b\|continuum" --exclude-dir=venv --exclude-dir=node_modules `
  --exclude-dir=.git --exclude=".env" --exclude="package-lock.json" .
```

Everything below is expected to remain, and nothing else should:

- `NIA_ENV_PATH` in the backward-compat fallback (10 files, each mirrored,
  so 20 hits). `NIAM_ENV_PATH` is read first; the old name still works, so
  updating `backend\.env` is yours to do whenever you like.
- `D:\niamm\Niam` paths in `.vscode\settings.json` and this runbook — those go
  with F4.5, the folder rename, after the demo.
- `container_name: niam-neo4j` / `nia-backend` / `nia-frontend` in
  `docker-compose.yml`. **Deliberately left.** Renaming them now would make
  `docker compose up -d neo4j` try to create a *new* container on ports
  7474/7687 while yours is still running, and the port clash would look
  like a Docker fault. G4 already rewrites this file — it belongs there.

## Check on screen

Sidebar reads **Niam**, login page says "Sign in to your Niam workspace",
browser tab reads **Niam Dashboard**. `GET /api/v1/` returns
`"service": "niam-api"`.

## The clause-applicability fix

Re-run reconciliation to pick up the new `coverage_basis` property:
```powershell
python -m reconciliation.run_reconciliation --system niam-smoke --yes
```

```cypher
MATCH (g:Gap) RETURN g.coverage_basis, count(*) ORDER BY g.coverage_basis;
```

Expect mostly `"general"`. That is the correct reading: the DPDP Act writes
notice, consent, rights and cross-border transfer about personal data as
such, not about categories of it. What changed is that the tool now *says*
which basis a finding rests on, instead of presenting a general obligation
as though the Act singled that data out.

On the **Graph** page, hovering a data type now reads like
`3 obligation(s) apply, none in force yet — 1 naming it, 2 general`, and far
fewer nodes are red: judging coverage on directly-attached clauses alone
was harsher than the Act supports. Vendors, the graph, and the gap engine
now share one definition of "covered" (`FIDUCIARY_OBLIGATION_SECTIONS` in
`legal/commencement.py`) — before this they disagreed with each other.

### Optional: re-extract the Act

The extractor prompt now asks for specific categories *and* broad
applicability, rather than treating them as either/or. Clause extraction is
cached, so nothing changes until you force it:
```powershell
python -m legal.load_dpdp_clauses --yes --refresh
```
That costs ~22 Gemini calls and about two minutes. Worth doing once before
the demo to see whether more sections come back naming a category; not
worth doing twice.

### Unit tests

```powershell
pip install pytest
python -m pytest reconciliation/test_reconciler.py reasoning/test_verifier.py -q
```
19 tests, all passing here.
