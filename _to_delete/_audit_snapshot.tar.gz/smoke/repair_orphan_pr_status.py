"""
One-off repair: gaps that claim to be with legal, but are not.

mark_pr_opened() wrote status = 'pr_opened' onto the :Gap durably, while
the pull request itself lived in a process dictionary. Any restart left
the claim without its subject -- which is how "Postal address -> Database"
came to read "With legal" on the findings page and appear in no review
queue anywhere.

The API now derives the status from the :PullRequest node rather than
trusting the property, so those gaps already display correctly. This
script fixes the stored data to match, so the two never have to be
reconciled again at read time.

    python smoke\\repair_orphan_pr_status.py            # report only
    python smoke\\repair_orphan_pr_status.py --write    # fix them

Reads NEO4J_* from the environment, like every other CLI here. Point it at
whichever instance you mean to repair -- it does not choose for you.
"""

import argparse
import os
import sys
from datetime import datetime, timezone

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _ROOT)

# neo4j_client resolves its .env with find_dotenv("../backend/.env",
# usecwd=True), which only lands when you are standing in intelligence/.
# Point it at the file directly -- computed from this script's own
# location -- so the repair runs from whatever directory you happen to be
# in. This sets a PATH, and reads nothing.
os.environ.setdefault("NIAM_ENV_PATH", os.path.join(_ROOT, "backend", ".env"))

from graph.neo4j_client import Neo4jClient  # noqa: E402

FIND = """
MATCH (g:Gap)
WHERE g.status = 'pr_opened' AND NOT (g)-[:HAS_PR]->(:PullRequest)
RETURN g.id AS id, g.title AS title, g.pr_id AS pr_id
ORDER BY g.id
"""

# Downgraded to fix_generated, not open: the remediation drafts are real
# and were generated. It is the review that never reached GitHub.
REPAIR = """
MATCH (g:Gap)
WHERE g.status = 'pr_opened' AND NOT (g)-[:HAS_PR]->(:PullRequest)
SET g.status = 'fix_generated',
    g.pr_id = null,
    g.updated_at = $now
RETURN count(g) AS repaired
"""


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--write", action="store_true", help="apply the repair (default: report only)"
    )
    args = parser.parse_args()

    client = Neo4jClient()
    try:
        rows = client.run_read(FIND)
        if not rows:
            print("Nothing to repair: every 'pr_opened' gap has a :PullRequest.")
            return 0

        print(f"{len(rows)} gap(s) claim a pull request that does not exist:\n")
        for r in rows:
            print(f"  {r['id']}  {r['title']}  (pr_id={r['pr_id']})")

        if not args.write:
            print("\nReport only. Re-run with --write to set them to fix_generated.")
            return 0

        now = datetime.now(timezone.utc).isoformat()
        repaired = client.run_write(REPAIR, {"now": now})[0]["repaired"]
        print(f"\nRepaired {repaired} gap(s) -> fix_generated.")
    finally:
        client.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
