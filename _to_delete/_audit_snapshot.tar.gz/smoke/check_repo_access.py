"""Diagnose a scanner 404 against a GitHub repo.

IMPORTANT: this uses the SAME credential the scanner uses -- GITHUB_TOKEN
loaded from .env -- not the `gh` CLI's separate login. `gh repo view`
succeeding does NOT mean the scanner can read the repo.

Never prints the token. Run from the intelligence/ directory:

    python ..\\smoke\\check_repo_access.py OWNER/REPO
"""
import os
import sys

sys.path.insert(0, os.getcwd())

import requests  # noqa: E402
from ingestion.github.utils import github_headers  # noqa: E402

repo = sys.argv[1] if len(sys.argv) > 1 else None
if not repo or "/" not in repo:
    sys.exit("usage: python ..\\smoke\\check_repo_access.py OWNER/REPO")

token = os.getenv("GITHUB_TOKEN") or ""
if not token:
    print("GITHUB_TOKEN: MISSING -- the scanner cannot authenticate at all.")
else:
    kind = ("fine-grained" if token.startswith("github_pat_")
            else "classic" if token.startswith("ghp_")
            else "unknown format")
    print(f"GITHUB_TOKEN: present, {len(token)} chars, {kind}")

h = github_headers(token)
api = "https://api.github.com"

r = requests.get(f"{api}/user", headers=h, timeout=20)
print(f"\n[1] token identity      -> {r.status_code} "
      f"{r.json().get('login') if r.ok else r.text[:120]}")

r = requests.get(f"{api}/repos/{repo}", headers=h, timeout=20)
print(f"[2] repo visible        -> {r.status_code}", end=" ")
default_branch = None
if r.ok:
    j = r.json()
    default_branch = j.get("default_branch")
    print(f"private={j.get('private')} default_branch={default_branch!r} "
          f"size={j.get('size')}KB")
else:
    print(r.json().get("message", r.text[:120]))

r = requests.get(f"{api}/repos/{repo}/branches", headers=h, timeout=20)
if r.ok:
    names = [b["name"] for b in r.json()]
    print(f"[3] branches            -> {names or 'NONE -- repo has no commits yet'}")
else:
    print(f"[3] branches            -> {r.status_code} "
          f"{r.json().get('message', '')}")

ref = default_branch or "main"
r = requests.get(f"{api}/repos/{repo}/git/trees/{ref}?recursive=1",
                 headers=h, timeout=20)
print(f"[4] tree @ {ref!r:8}     -> {r.status_code}", end=" ")
print(f"{len(r.json().get('tree', []))} entries" if r.ok
      else r.json().get("message", "")[:120])

print("\n--- verdict ---")
if not token:
    print("Set GITHUB_TOKEN in backend/.env (yourself -- Claude never opens it).")
elif r.ok:
    print(f"Scanner CAN read this repo. Use: --ref {ref}")
else:
    print("Scanner CANNOT read it. Most likely, in order:")
    print("  a) The repo has no commits -- an empty repo has no branch ref,")
    print("     so git/trees/<ref> 404s. Push the fixtures first.")
    print("  b) Fine-grained PAT without this repo selected. GitHub returns")
    print("     404 (not 403) for private repos a token cannot see -- add the")
    print("     repo under the token's 'Only select repositories'.")
    print(f"  c) Wrong default branch -- try --ref {default_branch or 'master'}.")
    print("  d) Username typo -- check [1] above against the owner in OWNER/REPO.")
