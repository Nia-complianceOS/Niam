# ============================================================
# Niam - commit batch 2 (Phase G, H, I.1 + UI work)
#
# Run from D:\niam\Niam in a NEW PowerShell window (T6 / CHECKS).
# It only stages and commits. It does NOT push - you push at the end,
# after reading the summary it prints.
#
#   cd D:\niam\Niam
#   powershell -ExecutionPolicy Bypass -File .\smoke\commit_batch2.ps1
# ============================================================

$ErrorActionPreference = 'Stop'

function Step($n, $text) { Write-Host ""; Write-Host "== $n : $text" -ForegroundColor Cyan }

# --- guard: right folder, nothing already staged ------------------------
if (-not (Test-Path .git))            { throw "Not a git repo. cd to D:\niam\Niam first." }
if (-not (Test-Path smoke\msg_h1.txt)){ throw "smoke\msg_h1.txt missing." }
if (Test-Path .git\index.lock)        { throw "Stale .git\index.lock - delete it, then re-run: Remove-Item .git\index.lock" }
if ((git diff --cached --name-only).Count -gt 0) {
    throw "Something is already staged. Run 'git reset' first, then re-run this script."
}

$branch = (git rev-parse --abbrev-ref HEAD).Trim()
Write-Host "Branch: $branch" -ForegroundColor Yellow
Write-Host "Before: $((git status --porcelain).Count) changed paths" -ForegroundColor Yellow

# ============================================================
# 1/4  Policy reconciliation (Phase H)
# ============================================================
Step "1/4" "policy reconciliation"
git add -A -- `
  intelligence/legal/policy_source.py `
  intelligence/legal/policy_extractor.py `
  intelligence/legal/load_policies.py `
  intelligence/reconciliation/reconciler.py `
  intelligence/reconciliation/test_reconciler.py `
  intelligence/graph/schema.py `
  intelligence/graph/edge_builder.py `
  intelligence/graph/graph_writer.py `
  intelligence/retrieval/queries.py `
  intelligence/reasoning/drafter.py `
  backend/app/services/github_service.py `
  backend/app/services/gap_service.py `
  backend/app/schemas/gaps.py
git --no-pager diff --cached --stat
git commit -F smoke\msg_h1.txt | Out-Host

# ============================================================
# 2/4  Structural cleanup (Phase G + I.1 Docker)
# ============================================================
Step "2/4" "structural cleanup - one copy of the intelligence package"
git add -A -- `
  backend/demo backend/graph backend/ingestion backend/legal `
  backend/reasoning backend/reconciliation backend/retrieval `
  intelligence/graph/write_graph_from_scan.py `
  intelligence/graph/run_scan_and_write.py `
  backend/app/api/v1/endpoints/webhook.py `
  backend/app/api/v1/endpoints/gaps.py `
  backend/app/core/config.py `
  backend/tests/test_dashboard_service.py `
  backend/Dockerfile Dockerfile .dockerignore docker-compose.yml
git --no-pager diff --cached --stat
git commit -F smoke\msg_h2.txt | Out-Host

# ============================================================
# 3/4  UI: gap selection + plain language
# ============================================================
Step "3/4" "ui - choose the finding to fix"
git add -A -- `
  frontend/src/lib/gapLanguage.ts `
  frontend/src/hooks/useGaps.ts `
  frontend/src/components/gaps `
  frontend/src/pages/Gaps.tsx `
  frontend/src/App.tsx `
  frontend/src/components/layout/Sidebar.tsx `
  frontend/src/pages/Dashboard.tsx `
  frontend/src/pages/PullRequests.tsx `
  frontend/src/pages/Repositories.tsx `
  frontend/src/components/repositories/ScanPanel.tsx `
  frontend/src/components/dashboard/PRReviewModal.tsx `
  frontend/src/types/api.ts `
  backend/app/schemas/repos.py
git --no-pager diff --cached --stat
git commit -F smoke\msg_h3.txt | Out-Host

# ============================================================
# 4/4  Graph layout + repository hygiene
#      The four internal docs stop being tracked here. They stay on
#      disk - 'git rm --cached' unstages them from git only.
# ============================================================
Step "4/4" "graph layout + gitignored working documents"
git rm --cached --quiet ACTION_PLAN.md CODEBASE_AUDIT.md KAMRAN_RUNBOOK.md SESSION_HANDOFF.md
git add -A -- `
  frontend/src/components/graph/ComplianceGraphCanvas.tsx `
  .gitignore README.md
git --no-pager diff --cached --stat
git commit -F smoke\msg_h4.txt | Out-Host

# ============================================================
# Report
# ============================================================
Write-Host ""
Write-Host "=================== RESULT ===================" -ForegroundColor Green
git --no-pager log --oneline -6
Write-Host ""
Write-Host "Still uncommitted (should be EMPTY or only smoke/ .vscode/):" -ForegroundColor Yellow
git status --porcelain
Write-Host ""
Write-Host "The four internal docs are still on disk:" -ForegroundColor Yellow
Get-ChildItem ACTION_PLAN.md, CODEBASE_AUDIT.md, KAMRAN_RUNBOOK.md, SESSION_HANDOFF.md -ErrorAction SilentlyContinue | Select-Object Name, Length | Format-Table
Write-Host "Nothing has been pushed yet. When the list above looks right:" -ForegroundColor Green
Write-Host "    git push origin $branch" -ForegroundColor White
