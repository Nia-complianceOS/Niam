# Niam pre-flight. Run from anywhere, with the venv already active:
#     D:\nia\NIA\smoke\preflight.ps1
# Prints no secrets -- only presence, lengths and paths.

$repo = "D:\nia\NIA"
$ok = $true

function Line($label, $value, $good) {
    $c = if ($good) { "Green" } else { "Red" }
    Write-Host ("{0,-10}: {1}" -f $label, $value) -ForegroundColor $c
}

Write-Host "`n--- Niam pre-flight ---" -ForegroundColor Cyan

# 1. venv Python
$py = (python -c "import sys; print(sys.executable)" 2>$null)
$pyOk = $py -like "*$repo\backend\venv\Scripts\python.exe"
Line "python" $(if ($py) { $py } else { "not found" }) $pyOk
if (-not $pyOk) {
    Write-Host "           -> run: $repo\backend\venv\Scripts\Activate.ps1 (in a FRESH window)" -ForegroundColor Yellow
    $ok = $false
}

# 2. Dependencies
python -c "import neo4j, dotenv, pypdf, google.genai, fastapi" 2>$null
$depOk = ($LASTEXITCODE -eq 0)
Line "deps" $(if ($depOk) { "ok" } else { "MISSING - you are probably on the system Python" }) $depOk
if (-not $depOk) { $ok = $false }

# 3. Smoke vars leaking into an Aura-facing window
$clean = -not $env:NEO4J_URI
Line "neo4j vars" $(if ($clean) { "clean (safe for Aura)" } else { "CONTAMINATED - smoke vars set, close this window" }) $clean

# 4. gh CLI + its identity (NOT the scanner's identity)
if (Get-Command gh -ErrorAction SilentlyContinue) {
    Line "gh login" (gh api user --jq .login 2>$null) $true
} else {
    Line "gh login" "not on PATH (fine - gh is never required; use github.com)" $true
}

# 5. Docker ENGINE, not just the CLI
docker info *> $null
$dockerOk = ($LASTEXITCODE -eq 0)
Line "docker" $(if ($dockerOk) { "engine up" } else { "engine DOWN - see S1-FIX, or use Neo4j Desktop (S1-ALT)" }) $dockerOk

# 6. What the SCANNER sees -- must load .env the same way the modules do.
#    A bare os.getenv() here is a false negative: nothing has loaded .env yet.
Push-Location "$repo\intelligence"
python -c @"
import os
from dotenv import load_dotenv, find_dotenv
p = os.getenv('NIA_ENV_PATH') or find_dotenv('../backend/.env', usecwd=True)
load_dotenv(p)
print('envfile   : ' + (p if p else 'NOT FOUND'))
for k in ('GITHUB_TOKEN', 'GEMINI_API_KEY', 'NEO4J_URI', 'NEO4J_PASSWORD'):
    v = os.getenv(k) or ''
    print('%-10s: %s' % (k, ('present, %d chars' % len(v)) if v else 'MISSING'))
"@
Pop-Location

Write-Host ""
if ($ok) { Write-Host "Pre-flight OK - proceed to the terminal layout." -ForegroundColor Green }
else     { Write-Host "Pre-flight FAILED - fix the red lines above first." -ForegroundColor Red }
Write-Host "Reminder: gh's login and GITHUB_TOKEN's account are different things (gotcha 5)." -ForegroundColor DarkGray
