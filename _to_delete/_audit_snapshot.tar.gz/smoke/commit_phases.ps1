# Commits the audit work (phases S, A, S4, B, C, E, F + D1) as five
# thematic commits, straight to main, then pushes.
#
# Per-phase history is not reconstructible: git records file states, and
# most files were edited across three or four phases. deps.py is the
# clearest example -- Phase A guarded the auth bypass, D1 deleted it, and
# only the deletion survives on disk. These five commits therefore group by
# AREA and each message names the phases it contains. The sequence ends at
# exactly the current working tree.
#
# Run from the repo root:  .\smoke\commit_phases.ps1

$ErrorActionPreference = "Stop"
Set-Location "D:\niam\Niam"

if (-not (git config user.email)) {
    Write-Host "git user.email is not set. Run these first:" -ForegroundColor Red
    Write-Host '  git config --global user.name "Your Name"'
    Write-Host '  git config --global user.email "you@example.com"'
    exit 1
}

function Commit-Group {
    param([string[]]$Paths, [string]$Message)
    git add -- $Paths
    if (git diff --cached --quiet) {
        Write-Host "nothing staged, skipping: $Message" -ForegroundColor Yellow
        return
    }
    git commit -q -m $Message
    Write-Host "committed: $(git log --oneline -1)" -ForegroundColor Green
}

# --- 1. security and authentication -----------------------------------
Commit-Group @(
    "backend/app/api/deps.py",
    "backend/app/api/v1/endpoints/auth.py",
    "backend/app/main.py",
    "backend/app/core/config.py",
    "backend/app/services/github_service.py",
    "backend/app/services/user_service.py",
    "backend/requirements.txt",
    "frontend/src/context/AuthContext.tsx",
    "frontend/src/pages/Login.tsx",
    "frontend/src/pages/Signup.tsx",
    "frontend/src/services/api/client.ts"
) @"
security: real auth, and close the world-callable PR bot

Phases A1/A2 and decision D1.

Auth was a hardcoded bypass: deps.py authenticated any request bearing
"mock-token-123", and AuthContext handed that token to anyone who
submitted the login form, so every protected route was open. A1 guarded
it behind APP_ENV; D1 deleted it outright once this became a deployed
project. The machinery it stood in for was complete the whole time --
core/auth.py issues JWTs, user_service stores :User nodes with hashed
passwords -- so the frontend now calls POST /auth/login and /auth/signup
for real, and GET /auth/me validates a stored token on load instead of
trusting localStorage.

open_compliance_pr() writes to GitHub with a real credential and was
reachable unauthenticated. It now requires GITHUB_DRY_RUN=false and an
explicit PR_ALLOWED_REPOS entry, both fail-closed by default, and the
hardcoded "nova-labs/checkout-service" fallback target is gone: a gap
with no source commit raises 400 rather than aiming at someone else's
repo.

requirements.txt was a partial freeze missing pypdf (imported by
legal/dpdp_source.py) and listing bcrypt without it being installed, so
/auth/signup would have 500'd. Now direct dependencies only, pinned to
the installed versions; SQLAlchemy and psycopg2-binary dropped as unused.

Co-Authored-By: Claude Opus 5 <noreply@anthropic.com>
Claude-Session: https://claude.ai/code/session_01QXu2jh7ar23a31CVw7S4Ef
"@

# --- 2. the intelligence engine ---------------------------------------
Commit-Group @(
    "intelligence",
    "backend/demo", "backend/graph", "backend/ingestion", "backend/legal",
    "backend/reasoning", "backend/reconciliation", "backend/retrieval"
) @"
intelligence: commit provenance, gap classification, and Act parsing

Phases A3/A4, S4, E1-E6, and the clause-applicability fix.

The gap engine wrote nothing against a fully populated graph. classify_gap
asked "is any clause in force" over a set that DPDPRetriever merges
general-purpose clauses into -- and the only sections in force today are
s.36 and s.37, the Government's powers to call for information and issue
directions. Every data type inherited them, every one classified as
covered, and 15 data types across 8 vendors produced zero gaps while
reporting success. Coverage is now limited to the sections that oblige a
Data Fiduciary (ss.3-17), defined in commencement.py and shared with the
API layer.

Gaps carry a real source commit. The scanner resolves a ref to a commit
once and reads the tree at that SHA, then stamps repo/sha/author/date onto
every candidate -- previously the CLI recorded the literal string "main"
as a commit and the API scan path stamped nothing at all, so no gap could
ever have a source repository and open-pr had no target.

Also: gap ids are system-scoped (a second system used to MERGE onto the
first's gaps -- a genuine multi-tenancy bug); provenance dedupes on a
timestamp-free key instead of growing on every re-scan; remote blobs are
size-capped like local ones; the DPDP source validates its section count
at fetch time and matches extraction results by section number rather than
list position; and the verifier reports a not-yet-commenced clause as a
future obligation rather than a failed verification, which is the correct
reading when almost nothing in the Act commences before 2026-11-13.

Co-Authored-By: Claude Opus 5 <noreply@anthropic.com>
Claude-Session: https://claude.ai/code/session_01QXu2jh7ar23a31CVw7S4Ef
"@

# --- 3. backend API ----------------------------------------------------
Commit-Group @(
    "backend/app/services", "backend/app/schemas",
    "backend/app/api/v1/endpoints/graph.py",
    "backend/app/api/v1/endpoints/scan.py",
    "backend/app/api/v1/endpoints/webhook.py"
) @"
api: every number traces to the graph, or is not shown

Phases A3, C1-C3, E2/E3.

An empty graph reported 100% compliant: the score guarded its divide with
max(total, 1), so zero ungoverned over zero collected came out as perfect.
It now returns None, rendered as a dash. The invented defaults went with
it -- a hardcoded score of 73.0, a -4% movement nothing had measured, and
three "mapped controls" and three "affected systems" that were string
literals.

The dashboard reported "Graph unreachable" whenever any single label was
empty: the summary query chained non-optional MATCHes, so a fresh instance
was indistinguishable from an outage. Rewritten as independent COUNT {}
subqueries, defined once.

Vendors stop claiming connections that do not exist. connection_active was
defaulted true and never set, so all 13 rendered "Connected" -- they are
names an LLM read in source. It is now derived from provenance origin and
required by the schema.

/graph is bounded and reports it, its edges scoped to returned nodes so a
truncated view cannot hand D3 a dangling link, and node status is derived
from the graph rather than left "unknown" -- the legend described colours
nothing on screen used. Policies, repositories and the audit trail return
empty responses instead of 503s that leaked a roadmap filename to users.

Co-Authored-By: Claude Opus 5 <noreply@anthropic.com>
Claude-Session: https://claude.ai/code/session_01QXu2jh7ar23a31CVw7S4Ef
"@

# --- 4. frontend -------------------------------------------------------
Commit-Group @(
    "frontend/src", "frontend/index.html",
    "frontend/package.json", "frontend/package-lock.json"
) @"
frontend: honest screens, a reachable scan, and a usable graph

Phases C2-C5, E3.

Regulations.tsx was a byte-for-byte copy of PullRequests.tsx, down to
"export default function PullRequests" -- the route rendered the pull
request list, and RegulationsAccordion and useRegulations were mounted by
nothing. Every backend fix aimed at that page was invisible. It is now a
real page with the commencement countdown.

The compliance graph had no zoom, no pan and no node dragging, so any node
the force layout placed outside the 560px box was unreachable. It now pans,
zooms, drags, and frames everything with one click.

The dashboard's reconciliation timeline and commit feed were hardcoded
fiction -- a developer pushing Mixpanel to nova-labs/checkout-service --
and were not even behind USE_MOCKS, so no setting turned them off. The
commit feed is now built from real :Gap provenance; the timeline is empty
unless USE_MOCKS is set, and is labelled when it is.

Settings.tsx went from 338 lines to 104: a save button that was a
setTimeout, a prefilled webhook secret, and a Neo4j URI box hardcoded to
localhost while the instance runs on Aura. It is now a read-only health
panel. A repo input drives POST /scan directly, because the only scan
button lived on a page that 503'd and listed four repos that do not exist.

Co-Authored-By: Claude Opus 5 <noreply@anthropic.com>
Claude-Session: https://claude.ai/code/session_01QXu2jh7ar23a31CVw7S4Ef
"@

# --- 5. rename, config and documentation -------------------------------
Commit-Group @(
    "README.md", "ACTION_PLAN.md", "CODEBASE_AUDIT.md",
    "KAMRAN_RUNBOOK.md", "SESSION_HANDOFF.md",
    ".gitignore", ".vscode", "docker-compose.yml",
    "backend/.dockerignore", "backend/.env.example", "backend/render.yaml"
) @"
rename Nia/Continuum to Niam, and document what actually exists

Phase F, plus the deployment plan.

Three product names were live: NIA, nia, and Continuum -- the latter in
the API title, four loggers and a bot identity. All collapse to Niam.
NIA_ENV_PATH becomes NIAM_ENV_PATH, read as NIAM first and falling back to
the old name so no .env has to change. DEFAULT_SYSTEM_NAME becomes
niam-demo-system; it is a graph key, so the old :System node must be
deleted before the next scan rather than merged onto.

README rewritten. It claimed Tree-sitter (the scanner is a keyword
pre-filter feeding a taxonomy-constrained LLM classifier), gave an install
command listing five packages that are not dependencies while omitting the
ones that are, pointed at a venv location that does not exist, and left
reasoning/ and reconciliation/ -- the actual product -- out of the tree. It
now documents the real structure, working commands, and a limitations
section that states the four known gaps plainly.

The runbook and action plan gain a deployment phase: frontend on Vercel,
backend on Render, and why the backend cannot go on either Vercel or GitHub
Pages -- BackgroundTasks, an in-memory scan registry and a minutes-long SSE
stream do not survive serverless.

Co-Authored-By: Claude Opus 5 <noreply@anthropic.com>
Claude-Session: https://claude.ai/code/session_01QXu2jh7ar23a31CVw7S4Ef
"@

Write-Host ""
Write-Host "--- anything left uncommitted ---" -ForegroundColor Cyan
git status --porcelain
Write-Host ""
Write-Host "--- the five commits ---" -ForegroundColor Cyan
git --no-pager log --oneline -5
Write-Host ""
Write-Host "Review the above, then push with:  git push origin main" -ForegroundColor Yellow
