# Fixes the botched commit run.
#
# What went wrong: commit_phases.ps1 passed messages as PowerShell
# here-strings. Embedded quotes broke the parse, so groups 2-4 handed
# message WORDS to `git add` and never committed -- and the files they had
# already staged were swept into commit 5. So ad6d97f is labelled "rename
# and docs" while actually containing the intelligence engine, the API
# layer and the frontend.
#
# Nothing was pushed (origin/main is still b3f20de), so this just rewinds
# to the good first commit and redoes the rest with `git commit -F`, which
# has no quoting to get wrong.

$ErrorActionPreference = "Stop"
Set-Location "D:\niam\Niam"

$firstCommit = "c14b129"   # security: real auth, ... -- this one is correct

if ((git rev-parse --short HEAD) -eq $firstCommit) {
    Write-Host "already at the first commit, nothing to rewind" -ForegroundColor Yellow
} else {
    Write-Host "rewinding to $firstCommit (files are kept, only the commits are undone)" -ForegroundColor Cyan
    git reset --mixed $firstCommit
}

function Commit-Group {
    param(
        [Parameter(Mandatory)][string]$MessageFile,
        [Parameter(Mandatory, ValueFromRemainingArguments)][string[]]$Paths
    )
    git add -- $Paths
    git commit -q -F "smoke\$MessageFile"
    if ($LASTEXITCODE -ne 0) { throw "commit failed for $MessageFile" }
    Write-Host "committed: $(git log --oneline -1)" -ForegroundColor Green
}

Commit-Group "msg2_intelligence.txt" `
    "intelligence" "backend/demo" "backend/graph" "backend/ingestion" `
    "backend/legal" "backend/reasoning" "backend/reconciliation" "backend/retrieval"

Commit-Group "msg3_api.txt" `
    "backend/app/services" "backend/app/schemas" `
    "backend/app/api/v1/endpoints/graph.py" `
    "backend/app/api/v1/endpoints/scan.py" `
    "backend/app/api/v1/endpoints/webhook.py"

Commit-Group "msg4_frontend.txt" `
    "frontend/src" "frontend/index.html" "frontend/package.json" "frontend/package-lock.json"

Commit-Group "msg5_rename.txt" `
    "README.md" "ACTION_PLAN.md" "CODEBASE_AUDIT.md" "KAMRAN_RUNBOOK.md" `
    "SESSION_HANDOFF.md" ".gitignore" "docker-compose.yml" `
    "backend/.dockerignore" "backend/.env.example" "backend/render.yaml"

Write-Host ""
Write-Host "--- anything left uncommitted ---" -ForegroundColor Cyan
git status --porcelain
Write-Host ""
Write-Host "--- the five commits ---" -ForegroundColor Cyan
git --no-pager log --oneline -5
Write-Host ""
Write-Host "If that looks right:  git push origin main" -ForegroundColor Yellow
